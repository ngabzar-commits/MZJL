
import { Question } from "../../types";

export const jftA2b_1: Question[] = [
  {
    q: "週末は　デパートで　「買い物」を　しました。",
    q_romaji: "shuumatsu wa depaato de 'kaimono' o shimashita.",
    options: ["けんぶつ", "かいもの", "たべもの", "のりもの"],
    correct: 1,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: かいもの (Kaimono)**\n\n**Konteks Can-do (JFT Basic):**\nSoal ini menguji kosakata kegiatan sehari-hari.\n- **買い物 (Kaimono):** Belanja. Terdiri dari 買い (beli) + 物 (barang).\n\n**Analisis Pilihan Salah:**\n❌ **けんぶつ (Kenbutsu):** 見物 (Tamasya/Melihat-lihat pemandangan).\n❌ **たべもの (Tabemono):** 食べ物 (Makanan).\n❌ **のりもの (Norimono):** 乗り物 (Kendaraan)."
  },
  {
    q: "明日の　「予定」は　何ですか。",
    q_romaji: "ashita no 'yotei' wa nan desu ka.",
    options: ["よてい", "かてい", "ようじ", "やくそく"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: よてい (Yotei)**\n\n**Analisis Kata:**\n- **予定 (Yotei):** Jadwal / Rencana. (予: Sebelumnya, 定: Tentukan).\n\n**Perbedaan Nuansa:**\n- **用事 (Youji):** Urusan (tugas/janji yang harus dilakukan). 'Youji ga aru' (Ada urusan).\n- **約束 (Yakusoku):** Janji (dengan orang lain).\n- **家庭 (Katei):** Rumah tangga.\nDalam konteks menanyakan 'rencana besok secara umum', 'Yotei' paling tepat."
  },
  {
    q: "「有名」な　レストランで　食事しました。",
    q_romaji: "'yuumei' na resutoran de shokuji shimashita.",
    options: ["ゆうめい", "ゆうめ", "ゆめい", "ゆめ"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: ゆうめい (Yuumei)**\n\n**Analisis Fonetik (Bunyi Panjang):**\n- **有 (Yuu):** Ada.\n- **名 (Mei):** Nama.\n- Gabungan: Yuu-mei (Terkenal).\n\n**Jebakan:**\nSering salah dibaca pendek 'Yumei' atau 'Yume' (Mimpi)."
  },
  {
    q: "パーティーの　「準備」を　手伝います。",
    q_romaji: "paathii no 'junbi' o tetsudaimasu.",
    options: ["せつび", "しゅんび", "じゅんび", "ぜんび"],
    correct: 2,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: じゅんび (Junbi)**\n\n**Analisis Kata:**\n- **準備 (Junbi):** Persiapan.\n- **準 (Jun):** Standar/Semi.\n- **備 (Bi):** Melengkapi/Sedia.\n\n**Analisis Pilihan Salah:**\n❌ **せつび (Setsubi):** Fasilitas (設備).\n❌ **しゅんび / ぜんび:** Kata yang tidak umum atau salah baca."
  },
  {
    q: "「図書館」で　本を　借ります。",
    q_romaji: "'toshokan' de hon o karimasu.",
    options: ["どうぶつえん", "たいしかん", "びじゅつかん", "としょかん"],
    correct: 3,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: としょかん (Toshokan)**\n\n**Analisis Kata -kan (Bangunan):**\n- **図書館 (Toshokan):** Perpustakaan (Gambar/Buku + Tulis + Gedung).\n- **美術館 (Bijutsukan):** Museum Seni.\n- **大使館 (Taishikan):** Kedutaan Besar.\n- **動物園 (Doubutsuen):** Kebun Binatang (Akhiran -en, bukan -kan)."
  },
  {
    q: "「野菜」を　たくさん　食べます。",
    q_romaji: "'yasai' o takusan tabemasu.",
    options: ["くだもの", "やさい", "おかし", "にく"],
    correct: 1,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "✅ **Jawaban Benar: やさい (Yasai)**\n\n**Kategori Makanan:**\n- **野菜 (Yasai):** Sayuran.\n- **果物 (Kudamono):** Buah-buahan.\n- **お菓子 (Okashi):** Cemilan/Kue.\n- **肉 (Niku):** Daging.\n\nPenting untuk JFT Basic A2 (Topik Makanan)."
  }
];
