import { Question } from "../../types";

export const jftA2b_7: Question[] = [
  {
    q: "美術館の中です。\n係の人：「ここでは　写真を　＿＿＿　ください。」",
    options: ["撮らないで", "撮らなくて", "撮りないで", "撮るないで"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Larangan sopan: 'Nai-de kudasai' (Tolong jangan)."
  },
  {
    q: "工場で　注意を受けました。\n「危ないですから、ここには　＿＿＿。」",
    options: ["入らないで　ください", "入って　ください", "入ります", "入っても　いいです"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Peringatan bahaya: Tolong jangan masuk."
  },
  {
    q: "薬の　説明です。\n「ご飯を　＿＿＿　あとで、飲んでください。」",
    options: ["食べた", "食べる", "食べて", "食べ"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Setelah melakukan: Ta-form + ato de."
  },
  {
    q: "A:「ここに　車を　止めても　いいですか。」\nB:「いいえ、＿＿＿。」",
    options: ["いけません", "いいです", "かまいません", "止めます"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menolak izin: 'Ikemasen' (Tidak boleh)."
  },
  {
    q: "「右へ　＿＿＿と、駅が　あります。」",
    options: ["曲がる", "曲がって", "曲がり", "曲がろう"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Petunjuk jalan (To - kondisional): Kamus + to."
  }
];