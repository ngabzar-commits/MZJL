import { Question } from "../../types";

export const jftA2b_17: Question[] = [
  {
    q: "【会話】\n女：すみません、この　電車は　東京駅へ　行きますか。\n男：いいえ、これは　行きません。次の　電車ですよ。\n\n質問：女の人は　どの　電車に　乗りますか。",
    options: ["次の　電車", "今の　電車", "前の　電車", "乗らない"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Pria bilang 'Tsugi no densha' (Kereta berikutnya)."
  },
  {
    q: "【アナウンス】\n「次は　新宿、新宿です。お降りの方は　お忘れ物のないよう、ご注意ください。」\n\n質問：ここは　どこですか。",
    options: ["電車の中", "デパート", "学校", "病院"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Pengumuman stasiun/kereta."
  },
  {
    q: "【会話】\n医者：薬は　１日　３回、ご飯の　あとに　飲んでください。\n患者：わかりました。\n\n質問：薬は　いつ　飲みますか。",
    options: ["食後", "食前", "寝る前", "朝だけ"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Gohan no ato = Shokugo (Setelah makan)."
  },
  {
    q: "【会話】\n店員：温めますか。\n客：はい、お願いします。\n\n質問：ここは　どこですか。",
    options: ["コンビニ", "本屋", "銀行", "郵便局"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "'Atatamemasu ka' (Mau dihangatkan?) adalah frase khas Konbini saat beli Bento."
  },
  {
    q: "【会話】\n女：日曜日、映画を見に行きませんか。\n男：日曜日はちょっと用事があって…。土曜日はどうですか。\n女：いいですよ。\n\n質問：二人はいつ映画を見に行きますか。",
    options: ["土曜日", "日曜日", "月曜日", "行きません"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Pria menolak Minggu (Chotto...), mengusulkan Sabtu. Wanita setuju."
  }
];