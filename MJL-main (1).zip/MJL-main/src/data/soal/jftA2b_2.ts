import { Question } from "../../types";

export const jftA2b_2: Question[] = [
  {
    q: "ホテルを　＿＿＿　しました。",
    options: ["やくそく", "ようじ", "よやく", "よしゅう"],
    correct: 2,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Untuk hotel/restoran, kita melakukan 'Yoyaku' (Reservasi/Booking)."
  },
  {
    q: "暗いですね。電気を　＿＿＿　ください。",
    options: ["つけて", "あけて", "しめて", "けして"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Karena gelap (kurai), listrik/lampu dinyalakan (tsukete)."
  },
  {
    q: "友達と　映画を見る　＿＿＿が　あります。",
    options: ["やくそく", "よやく", "しゅうかん", "きそく"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Dengan teman kita membuat 'Yakusoku' (Janji)."
  },
  {
    q: "パソコンが　壊れましたから、＿＿＿　します。",
    options: ["しゅうり", "じゅんび", "ちゅうい", "しんぱい"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Karena rusak (kowaremashita), maka diperbaiki (Shuuri)."
  },
  {
    q: "この　料理は　＿＿＿から、砂糖を　入れます。",
    options: ["あまい", "からい", "すっぱい", "にがい"],
    correct: 1,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Karena pedas (karai), ditambahkan gula."
  }
];