import { Question } from "../../types";

export const jftA2b_6: Question[] = [
  {
    q: "A:「週末は　たいてい　何を　しますか。」\nB:「家で　映画を　＿＿＿。」",
    options: ["見たり　します", "見ます　します", "見て　します", "見る　します"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menyatakan contoh kegiatan (Tari-tari suru)."
  },
  {
    q: "私の　趣味は　写真を　＿＿＿　ことです。",
    options: ["撮る", "撮ります", "撮って", "撮った"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Hobi: Kamus + koto desu. (Toru koto desu)."
  },
  {
    q: "A:「一緒に　サッカーを　しませんか。」\nB:「すみません、サッカーは　ちょっと……。見るのは　好きですが、＿＿＿。」",
    options: ["するのは　苦手です", "するのは　上手です", "するのが　好きです", "して　います"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menolak karena tidak bisa main (Nigate/Lemah)."
  },
  {
    q: "毎晩　寝る　＿＿＿、歯を　磨きます。",
    options: ["前に", "後で", "とき", "ながら"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Sebelum tidur: 'Neru mae ni'."
  },
  {
    q: "暇な　とき、＿＿＿　音楽を　聞きます。",
    options: ["よく", "あまり", "ぜんぜん", "一度"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Frekuensi positif: 'Yoku' (Sering)."
  }
];