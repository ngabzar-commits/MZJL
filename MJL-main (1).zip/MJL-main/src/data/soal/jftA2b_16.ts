import { Question } from "../../types";

export const jftA2b_16: Question[] = [
  {
    q: "北海道は　東京＿＿＿　涼しいです。",
    options: ["より", "ほど", "ほう", "の"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Hokkaido LEBIH sejuk DARIPADA Tokyo. 'Yori'."
  },
  {
    q: "日本料理で　＿＿＿が　いちばん　好きですか。",
    options: ["何", "どこ", "いつ", "だれ"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menanyakan jenis masakan (Benda): 'Nani'."
  },
  {
    q: "バスと　電車と　＿＿＿が　速いですか。",
    options: ["どちら", "どこ", "どれ", "だれ"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Membandingkan 2 hal: 'Dochira'."
  },
  {
    q: "この　部屋は　＿＿＿　きれいです。",
    options: ["広くて", "広い", "広いくて", "広いな"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menyambung kata sifat-I: 'Kute'. Hiroi -> Hirokute."
  },
  {
    q: "山田さんは　＿＿＿　親切です。",
    options: ["元気で", "元気", "元気て", "元気な"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Menyambung kata sifat-Na: 'De'. Genki -> Genki de."
  },
  {
    q: "昨日は　＿＿＿　ですね。",
    options: ["寒かった", "寒いです", "寒いでした", "寒くでした"],
    correct: 0,
    type: "JFT_A2",
    inputType: "CHOICE",
    explanation: "Lampau KS-I: 'Katta'. Samui -> Samukatta."
  }
];