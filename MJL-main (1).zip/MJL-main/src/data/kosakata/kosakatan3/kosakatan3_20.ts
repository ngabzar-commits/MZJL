
import { Vocab } from "../../../types";

export const kosakatan3_20: Vocab[] = [
  // Akan diisi lebih lanjut
];
