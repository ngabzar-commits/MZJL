
import { Vocab } from "../../../types";

export const kosakatan3_19: Vocab[] = [
  // Akan diisi lebih lanjut
];
