
import { Vocab } from "../../../types";

export const kosakatan2_19: Vocab[] = [
  // Akan diisi lebih lanjut
];
