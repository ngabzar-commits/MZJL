
import { Vocab } from "../../../types";

export const kosakatan1_19: Vocab[] = [
  // Akan diisi lebih lanjut
];
