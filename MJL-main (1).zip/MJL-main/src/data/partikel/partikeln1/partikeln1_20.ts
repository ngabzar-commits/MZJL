
import { Particle } from "../../../types";

export const partikeln1_20: Particle[] = [
  // Akan diisi lebih lanjut
];
