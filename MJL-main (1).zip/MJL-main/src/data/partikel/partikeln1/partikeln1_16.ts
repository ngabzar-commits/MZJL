
import { Particle } from "../../../types";

export const partikeln1_16: Particle[] = [
  // Akan diisi lebih lanjut
];
