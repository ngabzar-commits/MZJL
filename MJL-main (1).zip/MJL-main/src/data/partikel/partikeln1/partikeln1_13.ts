
import { Particle } from "../../../types";

export const partikeln1_13: Particle[] = [
  // Akan diisi lebih lanjut
];
