
import { Particle } from "../../../types";

export const partikeln1_14: Particle[] = [
  // Akan diisi lebih lanjut
];
