
import { Particle } from "../../../types";

export const partikeln1_5: Particle[] = [
  { 
    char: 'だに (Da ni)', 
    usage: 'Hanya dengan... saja sudah...', 
    explanation: '[Rumus: KK(Kamus) / KB + だに] Membayangkannya/Mengingatnya saja sudah... (biasanya perasaan negatif/takut/terharu).', 
    example: '想像するだに恐ろしい (Membayangkannya saja sudah mengerikan).', 
    level: 'N1',
    examples: [
      { japanese: 'そんなことは夢にだに思わなかった。', romaji: 'Sonna koto wa yume ni da ni omowanakatta.', meaning: 'Hal itu bahkan dalam mimpi pun tidak pernah terpikirkan.' },
      { japanese: '微動だにしない。', romaji: 'Bidou da ni shinai.', meaning: 'Tidak bergerak sedikitpun (bahkan gerakan kecil pun tidak).' }
    ]
  },
  { 
    char: 'すら (Sura)', 
    usage: 'Bahkan...', 
    explanation: '[Rumus: KB (+Partikel) + すら] Bahkan... (Hal yang ekstrem/mendasar saja begitu, apalagi yang lain). Mirip "sae".', 
    example: '自分の名前すら書けない (Bahkan nama sendiri pun tidak bisa tulis).', 
    level: 'N1',
    examples: [
      { japanese: '忙しくて、食事をとる時間すらありません。', romaji: 'Isogashikute, shokuji o toru jikan sura arimasen.', meaning: 'Sangat sibuk, bahkan waktu makan pun tidak ada.' },
      { japanese: 'この問題は先生ですら解けなかった。', romaji: 'Kono mondai wa sensei de sura tokenakatta.', meaning: 'Masalah ini bahkan guru pun tidak bisa memecahkannya.' }
    ]
  },
  { 
    char: 'たりとも (Tari tomo)', 
    usage: 'Walau hanya (satu)... pun tidak', 
    explanation: '[Rumus: KB(Satuan Terkecil) + たりとも + ...ない] Meskipun hanya (satu detik/satu yen)... pun tidak (akan ditoleransi/dibiarkan).', 
    example: '一瞬たりとも気が抜けない (Tidak boleh lengah satu detik pun).', 
    level: 'N1',
    examples: [
      { japanese: '一円たりとも無駄にはできない。', romaji: 'Ichien tari tomo muda ni wa dekinai.', meaning: 'Satu yen pun tidak boleh disia-siakan.' },
      { japanese: '敵は一人たりとも逃がさない。', romaji: 'Teki wa hitori tari tomo nigasanai.', meaning: 'Musuh tidak akan kubiarkan lolos seorang pun.' }
    ]
  },
  { 
    char: 'つ～つ (Tsu... tsu)', 
    usage: 'Saling... (Bergantian)', 
    explanation: '[Rumus: KK(Masu-stem) + つ + KK(Masu-stem) + つ] Aksi berbalasan atau kontras yang terjadi bergantian (Saling).', 
    example: '持ちつ持たれつ (Saling tolong menolong / Take and give).', 
    level: 'N1',
    examples: [
      { japanese: '昨日のマラソンは、抜きつ抜かれつの大接戦だった。', romaji: 'Kinou no marason wa, nukitsu nukaretsu no daisessen datta.', meaning: 'Maraton kemarin adalah pertarungan sengit saling salip-menyalip.' },
      { japanese: '行きつ戻りつして、ようやくたどり着いた。', romaji: 'Yukitsu modoritsu shite, youyaku tadoritsuita.', meaning: 'Maju mundur (bolak-balik ragu), akhirnya sampai juga.' }
    ]
  },
  { 
    char: 'てやまない (Te yamanai)', 
    usage: 'Sangat / Tulus...', 
    explanation: '[Rumus: KK(Te) + やまない] Perasaan yang kuat dan tidak berhenti (tak henti-hentinya). Biasanya untuk doa, harapan, hormat.', 
    example: 'ご活躍を願ってやみません (Saya tak henti-hentinya berharap kesuksesan Anda).', 
    level: 'N1',
    examples: [
      { japanese: '世界平和を祈ってやみません。', romaji: 'Sekai heiwa o inotte yamimasen.', meaning: 'Saya tak henti-hentinya berdoa untuk perdamaian dunia.' },
      { japanese: '彼を尊敬してやまない。', romaji: 'Kare o sonkei shite yamanai.', meaning: 'Saya sangat menghormatinya.' }
    ]
  }
];
