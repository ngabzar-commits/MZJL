
import { Particle } from "../../../types";

export const partikeln1_12: Particle[] = [
  // Akan diisi lebih lanjut
];
