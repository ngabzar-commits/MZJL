
import { Particle } from "../../../types";

export const partikeln1_9: Particle[] = [
  // Akan diisi lebih lanjut
];
