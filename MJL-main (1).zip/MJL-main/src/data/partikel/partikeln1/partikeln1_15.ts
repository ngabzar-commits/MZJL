
import { Particle } from "../../../types";

export const partikeln1_15: Particle[] = [
  // Akan diisi lebih lanjut
];
