
import { Particle } from "../../../types";

export const partikeln1_6: Particle[] = [
  // Akan diisi lebih lanjut
];
