
import { Particle } from "../../../types";

export const partikeln1_11: Particle[] = [
  // Akan diisi lebih lanjut
];
