
import { Particle } from "../../../types";

export const partikeln1_8: Particle[] = [
  // Akan diisi lebih lanjut
];
