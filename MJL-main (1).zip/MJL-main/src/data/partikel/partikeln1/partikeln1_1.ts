
import { Particle } from "../../../types";

export const partikeln1_1: Particle[] = [
  { 
    char: 'なり (Nari)', 
    usage: 'Segera setelah (Mengejutkan)', 
    explanation: '[Rumus: KK(Kamus) + なり] Segera setelah melakukan A, langsung melakukan B. Biasanya subjeknya sama, dan aksi B adalah sesuatu yang mengejutkan atau di luar kebiasaan.', 
    example: '彼はコーヒーを飲むなり、吐き出してしまった (Begitu minum kopi, dia langsung memuntahkannya).', 
    level: 'N1',
    examples: [
      { japanese: '課長は部屋に入ってくるなり、怒鳴った。', romaji: 'Kachou wa heya ni haitte kuru nari, donatta.', meaning: 'Begitu kepala seksi masuk ruangan, dia langsung berteriak marah.' },
      { japanese: '子供は母親の顔を見るなり、泣き出した。', romaji: 'Kodomo wa hahaoya no kao o miru nari, nakidashita.', meaning: 'Begitu melihat wajah ibunya, anak itu langsung menangis.' },
      { japanese: '電話を切るなり、彼は外へ飛び出した。', romaji: 'Denwa o kiru nari, kare wa soto e tobidashita.', meaning: 'Segera setelah menutup telepon, dia berlari keluar.' }
    ]
  },
  { 
    char: 'が早いか (Ga hayai ka)', 
    usage: 'Segera setelah (Hampir bersamaan)', 
    explanation: '[Rumus: KK(Kamus) + が早いか] Aksi A dan B terjadi hampir dalam waktu yang sama. Menekankan kecepatan reaksi.', 
    example: 'ベルが鳴るが早いか、生徒たちは教室を出た (Begitu bel berbunyi, siswa langsung keluar kelas).', 
    level: 'N1',
    examples: [
      { japanese: '彼女は僕の顔を見るが早いか、逃げ出した。', romaji: 'Kanojo wa boku no kao o miru ga hayai ka, nigedashita.', meaning: 'Begitu melihat wajahku, dia langsung kabur.' },
      { japanese: '電車が着くが早いか、乗客はドアに殺到した。', romaji: 'Densha ga tsuku ga hayai ka, joukyaku wa doa ni sattou shita.', meaning: 'Begitu kereta tiba, penumpang langsung menyerbu pintu.' },
      { japanese: '父は帰宅するが早いか、テレビをつけた。', romaji: 'Chichi wa kitaku suru ga hayai ka, terebi o tsuketa.', meaning: 'Begitu pulang ke rumah, ayah langsung menyalakan TV.' }
    ]
  },
  { 
    char: 'や / や否や (Ya / Ya ina ya)', 
    usage: 'Baru saja... tiba-tiba...', 
    explanation: '[Rumus: KK(Kamus) + や / や否や] Segera setelah A terjadi, B terjadi. Sering digunakan untuk kejadian alam atau situasi di luar kendali.', 
    example: '空が暗くなるや否や、激しい雨が降り始めた (Begitu langit gelap, hujan deras mulai turun).', 
    level: 'N1',
    examples: [
      { japanese: 'その男は警官の姿を見るや、逃げ出した。', romaji: 'Sono otoko wa keikan no sugata o miru ya, nigedashita.', meaning: 'Pria itu segera kabur begitu melihat sosok polisi.' },
      { japanese: '開演のベルが鳴るや否や、会場は静まり返った。', romaji: 'Kaien no beru ga naru ya ina ya, kaijou wa shizumari kaetta.', meaning: 'Begitu bel tanda mulai berbunyi, tempat acara menjadi sunyi senyap.' }
    ]
  },
  { 
    char: 'そばから (Soba kara)', 
    usage: 'Baru saja... (Langsung terulang lagi)', 
    explanation: '[Rumus: KK(Kamus/Ta) + そばから] Meskipun sudah melakukan A, segera terjadi B yang membatalkan/merusak hasil A. Menunjukkan pengulangan yang sia-sia.', 
    example: '片付けるそばから、子供が散らかす (Baru saja dibereskan, anak-anak langsung memberantakkannya lagi).', 
    level: 'N1',
    examples: [
      { japanese: '辞書で単語を覚えるそばから忘れていく。', romaji: 'Jisho de tango o oboeru soba kara wasurete iku.', meaning: 'Baru saja menghafal kosakata dari kamus, langsung lupa lagi.' },
      { japanese: '雑草は抜くそばから生えてくる。', romaji: 'Zassou wa nuku soba kara haete kuru.', meaning: 'Rumput liar itu baru dicabut langsung tumbuh lagi.' }
    ]
  },
  { 
    char: 'てからというもの (Te kara to iu mono)', 
    usage: 'Semenjak (Perubahan besar)', 
    explanation: '[Rumus: KK(Te) + からというもの] Sejak peristiwa A, terjadi perubahan besar dan keadaan B terus berlanjut hingga sekarang. Tidak dipakai untuk waktu yang singkat.', 
    example: '日本に来てからというもの、考え方が変わった (Semenjak datang ke Jepang, cara pandang saya berubah).', 
    level: 'N1',
    examples: [
      { japanese: '娘が生まれてからというもの、彼は酒を飲まなくなった。', romaji: 'Musume ga umarete kara to iu mono, kare wa sake o nomanaku natta.', meaning: 'Semenjak putrinya lahir, dia sama sekali tidak minum alkohol lagi.' },
      { japanese: 'あの事故があってからというもの、彼は運転をやめた。', romaji: 'Ano jiko ga atte kara to iu mono, kare wa unten o yameta.', meaning: 'Semenjak kecelakaan itu, dia berhenti mengemudi.' }
    ]
  }
];
