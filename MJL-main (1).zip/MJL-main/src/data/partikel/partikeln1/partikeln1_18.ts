
import { Particle } from "../../../types";

export const partikeln1_18: Particle[] = [
  // Akan diisi lebih lanjut
];
