
import { Particle } from "../../../types";

export const partikeln1_10: Particle[] = [
  // Akan diisi lebih lanjut
];
