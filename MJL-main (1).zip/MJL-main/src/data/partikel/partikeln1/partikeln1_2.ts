
import { Particle } from "../../../types";

export const partikeln1_2: Particle[] = [
  { 
    char: 'あっての (Atte no)', 
    usage: 'Ada berkat / Bergantung pada', 
    explanation: '[Rumus: KB + あっての + KB] B bisa eksis/sukses KARENA ada A. Tanpa A, B tidak mungkin ada. Menunjukkan rasa syukur atau pentingnya A.', 
    example: 'お客様あっての私たちです (Kami ada karena adanya pelanggan).', 
    level: 'N1',
    examples: [
      { japanese: '健康あっての仕事だ。無理はいけない。', romaji: 'Kenkou atte no shigoto da. Muri wa ikenai.', meaning: 'Pekerjaan itu ada karena kesehatan (kesehatan yang utama). Jangan memaksakan diri.' },
      { japanese: '日々の練習あっての勝利だ。', romaji: 'Hibi no renshuu atte no shouri da.', meaning: 'Kemenangan ini ada berkat latihan setiap hari.' }
    ]
  },
  { 
    char: '極まりない (Kiwamarinai)', 
    usage: 'Sangat / Tak terhingga (Negatif)', 
    explanation: '[Rumus: KS-Na(tanpa na) + 極まりない] Menunjukkan tingkat yang ekstrem, biasanya untuk hal negatif atau kritis.', 
    example: '失礼極まりない態度だ (Sikap yang sungguh sangat tidak sopan).', 
    level: 'N1',
    examples: [
      { japanese: '危険極まりない行為だ。', romaji: 'Kiken kiwamarinai koui da.', meaning: 'Itu adalah tindakan yang sangat berbahaya.' },
      { japanese: 'その説明は不愉快極まりない。', romaji: 'Sono setsumei wa fuyukai kiwamarinai.', meaning: 'Penjelasan itu sangat tidak menyenangkan.' }
    ]
  },
  { 
    char: 'ごとき (Gotoki)', 
    usage: 'Seperti / Sekelas (Merendahkan)', 
    explanation: '[Rumus: KB + の + ごとき] Seperti... (Kiasan). Jika dipakai untuk orang (terutama diri sendiri), bermakna merendahkan ("Orang sekelas saya...").', 
    example: '私ごときが意見を言うのは失礼ですが... (Tidak sopan bagi orang rendahan seperti saya berpendapat, tapi...).', 
    level: 'N1',
    examples: [
      { japanese: '光陰矢のごとし。', romaji: 'Kouin ya no gotoshi.', meaning: 'Waktu berlalu seperti anak panah (cepat sekali).' },
      { japanese: 'お前ごときに何ができる。', romaji: 'Omae gotoki ni nani ga dekiru.', meaning: 'Apa yang bisa dilakukan oleh orang sepertimu?' }
    ]
  },
  { 
    char: '始末だ (Shimatsu da)', 
    usage: 'Berakhir menjadi... (Buruk)', 
    explanation: '[Rumus: KK(Kamus) + 始末だ] Akhirnya menjadi... (hasil yang buruk). Setelah proses negatif, berakhir dengan keadaan menyedihkan ini.', 
    example: '遊んでばかりいて、学校を辞める始末だ (Main melulu, akhirnya sampai berhenti sekolah).', 
    level: 'N1',
    examples: [
      { japanese: '息子は家出をして、警察に補導される始末だ。', romaji: 'Musuko wa iede o shite, keisatsu ni hodou sareru shimatsu da.', meaning: 'Anaknya kabur, dan akhirnya diamankan polisi.' },
      { japanese: '昨日は飲みすぎて、駅で寝てしまう始末だった。', romaji: 'Kinou wa nomisugite, eki de nete shimau shimatsu datta.', meaning: 'Kemarin minum terlalu banyak, akhirnya malah tidur di stasiun.' }
    ]
  },
  { 
    char: 'ずくめ (Zukume)', 
    usage: 'Penuh dengan / Serba', 
    explanation: '[Rumus: KB + ずくめ] Penuh dengan... / Semuanya... (Biasanya hal yang baik atau warna pakaian).', 
    example: '黒ずくめの男 (Pria berpakaian serba hitam).', 
    level: 'N1',
    examples: [
      { japanese: 'この旅行はいいことずくめだった。', romaji: 'Kono ryokou wa ii koto zukume datta.', meaning: 'Perjalanan ini penuh dengan hal-hal baik.' },
      { japanese: '幸せずくめの人生なんてない。', romaji: 'Shiawase zukume no jinsei nante nai.', meaning: 'Tidak ada hidup yang isinya bahagia melulu.' }
    ]
  }
];
