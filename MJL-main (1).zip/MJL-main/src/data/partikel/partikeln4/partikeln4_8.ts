import { Particle } from "../../../types";

export const partikeln4_8: Particle[] = [
  // Tambahkan partikel lainnya
];