import { Particle } from "../../../types";

export const partikeln4_20: Particle[] = [
  // Tambahkan partikel lainnya
];