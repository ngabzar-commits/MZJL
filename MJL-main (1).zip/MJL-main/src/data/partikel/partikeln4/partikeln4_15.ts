import { Particle } from "../../../types";

export const partikeln4_15: Particle[] = [
  // Tambahkan partikel lainnya
];