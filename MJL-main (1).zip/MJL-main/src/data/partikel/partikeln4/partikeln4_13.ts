import { Particle } from "../../../types";

export const partikeln4_13: Particle[] = [
  // Tambahkan partikel lainnya
];