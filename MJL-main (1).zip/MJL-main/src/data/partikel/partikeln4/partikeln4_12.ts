import { Particle } from "../../../types";

export const partikeln4_12: Particle[] = [
  // Tambahkan partikel lainnya
];