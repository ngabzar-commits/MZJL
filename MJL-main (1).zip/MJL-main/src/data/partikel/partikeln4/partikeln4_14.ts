import { Particle } from "../../../types";

export const partikeln4_14: Particle[] = [
  // Tambahkan partikel lainnya
];