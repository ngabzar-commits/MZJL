import { Particle } from "../../../types";

export const partikeln4_2: Particle[] = [
  { 
    char: 'だけ (Dake)', 
    usage: 'Hanya (Positif)', 
    explanation: 'Menyatakan batas "hanya". Biasanya digunakan dalam kalimat positif. Menggantikan partikel "o" atau "ga" (atau menempel padanya).', 
    example: 'これだけ買います (Saya hanya membeli ini).', 
    level: 'N4',
    examples: [
      { japanese: '一つだけください。', romaji: 'Hitotsu dake kudasai.', meaning: 'Tolong beri saya satu saja.' },
      { japanese: 'あなただけが好きです。', romaji: 'Anata dake ga suki desu.', meaning: 'Hanya kamu yang aku suka.' },
      { japanese: 'ローマ字だけ書けます。', romaji: 'Romaji dake kakemasu.', meaning: 'Saya hanya bisa menulis Romaji.' },
      { japanese: '少しだけ疲れました。', romaji: 'Sukoshi dake tsukaremashita.', meaning: 'Saya cuma sedikit lelah.' },
      { japanese: '日曜日だけ休みます。', romaji: 'Nichiyoubi dake yasumimasu.', meaning: 'Saya libur hanya hari Minggu.' }
    ]
  },
  { 
    char: 'しか (Shika)', 
    usage: 'Hanya (Negatif)', 
    explanation: 'Menyatakan "hanya", tetapi WAJIB diikuti kata kerja bentuk negatif. Nuansanya: "Tidak ada pilihan lain selain..." atau "Cuma ada sedikit".', 
    example: '千円しかありません (Cuma punya 1000 yen).', 
    level: 'N4',
    examples: [
      { japanese: 'ひらがなしか書けません。', romaji: 'Hiragana shika kakemasen.', meaning: 'Saya cuma bisa menulis Hiragana (yang lain tidak bisa).' },
      { japanese: '冷蔵庫に水しかありません。', romaji: 'Reizouko ni mizu shika arimasen.', meaning: 'Di kulkas cuma ada air (tidak ada makanan).' },
      { japanese: '１０分しか待ちません。', romaji: 'Juppun shika machimasen.', meaning: 'Saya cuma mau menunggu 10 menit.' },
      { japanese: '彼しか知りません。', romaji: 'Kare shika shirimasen.', meaning: 'Cuma dia yang tahu.' },
      { japanese: 'これしかありません。', romaji: 'Kore shika arimasen.', meaning: 'Cuma ada ini.' }
    ]
  },
  { 
    char: 'ばかり (Bakari)', 
    usage: 'Melulu / Terus-menerus', 
    explanation: 'Menyatakan suatu kegiatan dilakukan berulang-ulang atau hanya benda itu saja yang ada.', 
    example: '遊んでばかりいます (Main melulu).', 
    level: 'N4',
    examples: [
      { japanese: '弟はテレビを見てばかりいます。', romaji: 'Otouto wa terebi o mite bakari imasu.', meaning: 'Adik menonton TV melulu.' },
      { japanese: '肉ばかり食べないでください。', romaji: 'Niku bakari tabenaide kudasai.', meaning: 'Jangan makan daging melulu.' },
      { japanese: '嘘ばかりついています。', romaji: 'Uso bakari tsuite imasu.', meaning: 'Bohong melulu.' },
      { japanese: 'この店は高いものばかりです。', romaji: 'Kono mise wa takai mono bakari desu.', meaning: 'Toko ini barangnya mahal-mahal semua.' },
      { japanese: '寝てばかりいました。', romaji: 'Nete bakari imashita.', meaning: 'Tidur melulu (kerjaannya).' }
    ]
  }
];