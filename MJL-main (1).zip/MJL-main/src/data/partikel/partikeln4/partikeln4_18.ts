import { Particle } from "../../../types";

export const partikeln4_18: Particle[] = [
  // Tambahkan partikel lainnya
];