
import { Particle } from "../../../types";

export const partikeln3_16: Particle[] = [
  // Akan diisi lebih lanjut
];
