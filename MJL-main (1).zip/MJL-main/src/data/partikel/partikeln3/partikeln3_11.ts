
import { Particle } from "../../../types";

export const partikeln3_11: Particle[] = [
  // Akan diisi lebih lanjut
];
