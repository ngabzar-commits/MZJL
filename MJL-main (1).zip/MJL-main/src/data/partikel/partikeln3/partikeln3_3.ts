
import { Particle } from "../../../types";

export const partikeln3_3: Particle[] = [
  { 
    char: 'やら (Yara)', 
    usage: 'Dan lain-lain / Entah...entah', 
    explanation: 'Menyebutkan contoh yang banyak/kacau, atau menunjukkan ketidakpastian.', 
    example: '嬉しいやら悲しいやらで、複雑な気持ちだ (Antara senang dan sedih, perasaanku campur aduk).', 
    level: 'N3',
    examples: [
      { japanese: '部屋には本やら服やらが散らかっている。', romaji: 'Heya ni wa hon yara fuku yara ga chirakatte iru.', meaning: 'Di kamar berserakan buku, baju, dan lain-lain.' },
      { japanese: 'どこに鍵を置いたのやら、見つからない。', romaji: 'Doko ni kagi o oita no yara, mitsukaranai.', meaning: 'Entah di mana menaruh kuncinya, tidak ketemu.' },
      { japanese: '来月は出張やら会議やらで忙しい。', romaji: 'Raigetsu wa shucchou yara kaigi yara de isogashii.', meaning: 'Bulan depan sibuk dengan dinas luar kota, rapat, dan sebagainya.' },
      { japanese: '何やら怪しい音がする。', romaji: 'Nani yara ayashii oto ga suru.', meaning: 'Terdengar suara yang entah kenapa mencurigakan.' }
    ]
  },
  { 
    char: 'とも (Tomo)', 
    usage: 'Tentu saja / Walaupun / Paling tidak', 
    explanation: '1. Penekanan persetujuan (Tentu!). 2. Walaupun (dengan kata tanya/negatif). 3. Paling sedikit (Sukunakutomo).', 
    example: '行きますとも (Tentu saja saya pergi).', 
    level: 'N3',
    examples: [
      { japanese: '遅くとも５時までには来てください。', romaji: 'Osokutomo goji made ni wa kite kudasai.', meaning: 'Paling lambat datanglah sebelum jam 5.' },
      { japanese: '「手伝ってくれる？」「いいとも。」', romaji: '"Tetsudatte kureru?" "Ii tomo."', meaning: '"Mau bantu?" "Tentu saja/Oke!"' },
      { japanese: 'どんなに難しくとも、やり遂げたい。', romaji: 'Donna ni muzukashikutomo,yaritogetai.', meaning: 'Sesulit apapun itu, saya ingin menyelesaikannya.' },
      { japanese: '少なくとも３人は必要だ。', romaji: 'Sukunakutomo sannin wa hitsuyou da.', meaning: 'Setidaknya butuh 3 orang.' }
    ]
  }
];
