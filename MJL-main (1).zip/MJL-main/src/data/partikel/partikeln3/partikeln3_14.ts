
import { Particle } from "../../../types";

export const partikeln3_14: Particle[] = [
  // Akan diisi lebih lanjut
];
