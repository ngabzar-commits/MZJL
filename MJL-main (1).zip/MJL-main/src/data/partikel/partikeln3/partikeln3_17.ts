
import { Particle } from "../../../types";

export const partikeln3_17: Particle[] = [
  // Akan diisi lebih lanjut
];
