
import { Particle } from "../../../types";

export const partikeln3_5: Particle[] = [
  { 
    char: 'について (Ni tsuite)', 
    usage: 'Tentang / Mengenai', 
    explanation: '[Rumus: KB + について] Menyatakan topik pembicaraan atau pemikiran.', 
    example: '日本の文化について勉強しています (Saya sedang belajar tentang budaya Jepang).', 
    level: 'N3',
    examples: [
      { japanese: 'この問題についてどう思いますか。', romaji: 'Kono mondai ni tsuite dou omoimasu ka.', meaning: 'Apa pendapat Anda tentang masalah ini?' },
      { japanese: '将来の仕事について考えている。', romaji: 'Shourai no shigoto ni tsuite kangaete iru.', meaning: 'Saya sedang memikirkan tentang pekerjaan masa depan.' },
      { japanese: '詳しいことについては、後で説明します。', romaji: 'Kuwashii koto ni tsuite wa, ato de setsumei shimasu.', meaning: 'Mengenai detailnya, akan saya jelaskan nanti.' }
    ]
  },
  { 
    char: 'にとって (Ni totte)', 
    usage: 'Bagi / Menurut (Sudut pandang)', 
    explanation: '[Rumus: KB + にとって] Menyatakan penilaian atau dampak dari sudut pandang seseorang.', 
    example: '私にとって家族は一番大切です (Bagi saya, keluarga adalah yang paling penting).', 
    level: 'N3',
    examples: [
      { japanese: '外国人にとって、漢字は難しい。', romaji: 'Gaikokujin ni totte, kanji wa muzukashii.', meaning: 'Bagi orang asing, kanji itu sulit.' },
      { japanese: '現代人にとって、スマホはなくてはならないものだ。', romaji: 'Gendaijin ni totte, sumaho wa nakute wa naranai mono da.', meaning: 'Bagi orang modern, smartphone adalah benda yang harus ada.' },
      { japanese: 'これはただの石ですが、私にとっては宝物です。', romaji: 'Kore wa tada no ishi desu ga, watashi ni totte wa takaramono desu.', meaning: 'Ini cuma batu biasa, tapi bagi saya ini harta karun.' }
    ]
  },
  { 
    char: 'に対して (Ni taishite)', 
    usage: 'Terhadap / Berlawanan dengan', 
    explanation: '[Rumus: KB + に対して] 1. Sikap/tindakan terhadap target. 2. Perbandingan kontras.', 
    example: '目上の人に対しては敬語を使うべきだ (Terhadap atasan, harus menggunakan bahasa hormat).', 
    level: 'N3',
    examples: [
      { japanese: '彼は誰に対しても親切だ。', romaji: 'Kare wa dare ni taishite mo shinsetsu da.', meaning: 'Dia ramah terhadap siapa saja.' },
      { japanese: '活発な姉に対して、妹は静かだ。', romaji: 'Kappatsu na ane ni taishite, imouto wa shizuka da.', meaning: 'Berlawanan dengan kakaknya yang aktif, adiknya pendiam.' },
      { japanese: 'お客様に対して失礼なことを言ってはいけない。', romaji: 'Okyakusama ni taishite shitsurei na koto o itte wa ikenai.', meaning: 'Tidak boleh berkata tidak sopan terhadap pelanggan.' }
    ]
  }
];
