import { Particle } from "../../../types";

export const partikeln5_20: Particle[] = [
  // Tambahkan partikel lainnya
];