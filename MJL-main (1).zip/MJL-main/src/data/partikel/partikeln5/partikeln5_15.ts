import { Particle } from "../../../types";

export const partikeln5_15: Particle[] = [
  // Tambahkan partikel lainnya
];