import { Particle } from "../../../types";

export const partikeln5_9: Particle[] = [
  // Tambahkan partikel lainnya
];