import { Particle } from "../../../types";

export const partikeln5_12: Particle[] = [
  // Tambahkan partikel lainnya
];