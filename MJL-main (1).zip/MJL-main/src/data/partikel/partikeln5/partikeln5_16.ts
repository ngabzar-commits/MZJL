import { Particle } from "../../../types";

export const partikeln5_16: Particle[] = [
  // Tambahkan partikel lainnya
];