import { Particle } from "../../../types";

export const partikeln5_7: Particle[] = [
  // Tambahkan partikel lainnya
];