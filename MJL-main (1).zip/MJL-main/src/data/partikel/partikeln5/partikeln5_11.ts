import { Particle } from "../../../types";

export const partikeln5_11: Particle[] = [
  // Tambahkan partikel lainnya
];