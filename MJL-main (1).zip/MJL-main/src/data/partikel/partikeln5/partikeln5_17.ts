import { Particle } from "../../../types";

export const partikeln5_17: Particle[] = [
  // Tambahkan partikel lainnya
];