import { Particle } from "../../../types";

export const partikeln5_1: Particle[] = [
  { 
    char: 'は (Wa)', 
    usage: 'Penanda Topik', 
    explanation: 'Partikel "Wa" (ditulis Ha) digunakan untuk menandai topik pembicaraan. Apa yang disebutkan sebelum "wa" adalah apa yang sedang kita bahas.',
    example: '私は学生です (Saya adalah siswa).', 
    level: 'N5',
    examples: [
      { japanese: '私は学生です。', romaji: 'Watashi wa gakusei desu.', meaning: 'Saya adalah seorang siswa.' },
      { japanese: 'これは私の本です。', romaji: 'Kore wa watashi no hon desu.', meaning: 'Ini adalah buku saya.' },
      { japanese: '山田さんは先生です。', romaji: 'Yamada-san wa sensei desu.', meaning: 'Sdr. Yamada adalah guru.' },
      { japanese: '今日はいい天気です。', romaji: 'Kyou wa ii tenki desu.', meaning: 'Hari ini cuacanya bagus.' },
      { japanese: 'トイレはどこですか。', romaji: 'Toire wa doko desu ka.', meaning: 'Toilet ada di mana?' }
    ]
  },
  { 
    char: 'は (Wa)', 
    usage: 'Perbandingan / Kontras', 
    explanation: 'Digunakan untuk menunjukkan kontras atau perbandingan antara dua hal. Biasanya digunakan dalam kalimat negatif.',
    example: '肉は食べますが、魚は食べません (Daging saya makan, tapi ikan tidak).', 
    level: 'N5',
    examples: [
      { japanese: '昼ごはん食べますが、朝ごはんは食べません。', romaji: 'Hirugohan wa tabemasu ga, asagohan wa tabemasen.', meaning: 'Makan siang saya makan, tapi sarapan tidak.' },
      { japanese: '英語はわかりますが、日本語はわかりません。', romaji: 'Eigo wa wakarimasu ga, Nihongo wa wakarimasen.', meaning: 'Bahasa Inggris paham, tapi Bahasa Jepang tidak paham.' },
      { japanese: 'ビールは飲みません。', romaji: 'Biiru wa nomimasen.', meaning: '(Kalau yang lain minum) Bir saya tidak minum.' },
      { japanese: 'テニスは好きではありません。', romaji: 'Tenisu wa suki dewa arimasen.', meaning: 'Saya tidak suka tenis (mungkin suka olahraga lain).' },
      { japanese: 'ここではタバコは吸えません。', romaji: 'Koko de wa tabako wa suemasen.', meaning: 'Di sini rokok tidak boleh dihisap.' }
    ]
  },
  { 
    char: 'が (Ga)', 
    usage: 'Penanda Subjek', 
    explanation: 'Menandai subjek gramatikal yang melakukan aksi, atau benda yang dideskripsikan keadaannya. Sering digunakan dengan kata kerja intransitif.',
    example: '雨が降っています (Hujan sedang turun).', 
    level: 'N5',
    examples: [
      { japanese: '雨が降っています。', romaji: 'Ame ga futte imasu.', meaning: 'Hujan sedang turun.' },
      { japanese: '誰が来ましたか。', romaji: 'Dare ga kimashita ka.', meaning: 'Siapa yang datang?' },
      { japanese: '猫がいます。', romaji: 'Neko ga imasu.', meaning: 'Ada kucing.' },
      { japanese: '桜が咲きました。', romaji: 'Sakura ga sakimashita.', meaning: 'Bunga sakura sudah mekar.' },
      { japanese: 'バスが来ました。', romaji: 'Basu ga kimashita.', meaning: 'Bus sudah datang.' }
    ]
  },
  { 
    char: 'が (Ga)', 
    usage: 'Objek Keinginan / Kemampuan', 
    explanation: 'Khusus digunakan sebelum kata sifat "suki/kirai" (suka/benci), "jouzu/heta" (pandai/bodoh), dan kata kerja bentuk potensial (bisa) atau "hoshii" (ingin).',
    example: '私は猫が好きです (Saya suka kucing).', 
    level: 'N5',
    examples: [
      { japanese: '私は猫が好きです。', romaji: 'Watashi wa neko ga suki desu.', meaning: 'Saya suka kucing.' },
      { japanese: '日本語がわかります。', romaji: 'Nihongo ga wakarimasu.', meaning: 'Saya mengerti bahasa Jepang.' },
      { japanese: '歌が上手です。', romaji: 'Uta ga jouzu desu.', meaning: 'Pandai bernyanyi.' },
      { japanese: '新しい車が欲しいです。', romaji: 'Atarashii kuruma ga hoshii desu.', meaning: 'Saya ingin mobil baru.' },
      { japanese: '漢字が書けます。', romaji: 'Kanji ga kakemasu.', meaning: 'Saya bisa menulis Kanji.' }
    ]
  },
  { 
    char: 'を (O)', 
    usage: 'Penanda Objek Langsung', 
    explanation: 'Menandai objek yang dikenai tindakan oleh kata kerja transitif.',
    example: 'ご飯を食べます (Makan nasi).', 
    level: 'N5',
    examples: [
      { japanese: 'ご飯を食べます。', romaji: 'Gohan o tabemasu.', meaning: 'Makan nasi.' },
      { japanese: '本を読みます。', romaji: 'Hon o yomimasu.', meaning: 'Membaca buku.' },
      { japanese: '水を飲みます。', romaji: 'Mizu o nomimasu.', meaning: 'Minum air.' },
      { japanese: 'テレビを見ます。', romaji: 'Terebi o mimasu.', meaning: 'Menonton TV.' },
      { japanese: '日本語を勉強します。', romaji: 'Nihongo o benkyou shimasu.', meaning: 'Belajar bahasa Jepang.' }
    ]
  },
  { 
    char: 'を (O)', 
    usage: 'Tempat yang Dilalui / Ditinggalkan', 
    explanation: 'Digunakan dengan kata kerja gerak untuk menunjukkan tempat yang dilalui (seperti lewat jalan) atau tempat asal keluar (seperti turun dari kereta).',
    example: '公園を散歩します (Jalan-jalan di taman).', 
    level: 'N5',
    examples: [
      { japanese: '公園を散歩します。', romaji: 'Kouen o sanpo shimasu.', meaning: 'Jalan-jalan di taman.' },
      { japanese: '道を渡ります。', romaji: 'Michi o watarimasu.', meaning: 'Menyeberang jalan.' },
      { japanese: '電車を降ります。', romaji: 'Densha o orimasu.', meaning: 'Turun dari kereta.' },
      { japanese: '家を出ます。', romaji: 'Uchi o demasu.', meaning: 'Keluar dari rumah.' },
      { japanese: '空を飛びます。', romaji: 'Sora o tobimasu.', meaning: 'Terbang di langit.' }
    ]
  }
];