import { Particle } from "../../../types";

export const partikeln5_10: Particle[] = [
  // Tambahkan partikel lainnya
];