import { Particle } from "../../../types";

export const partikeln5_18: Particle[] = [
  // Tambahkan partikel lainnya
];