import { Particle } from "../../../types";

export const partikeln5_13: Particle[] = [
  // Tambahkan partikel lainnya
];