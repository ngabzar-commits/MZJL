import { Particle } from "../../../types";

export const partikeln5_19: Particle[] = [
  // Tambahkan partikel lainnya
];