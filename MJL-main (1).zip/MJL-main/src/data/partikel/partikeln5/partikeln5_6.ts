import { Particle } from "../../../types";

export const partikeln5_6: Particle[] = [
  // Tambahkan partikel lainnya
];