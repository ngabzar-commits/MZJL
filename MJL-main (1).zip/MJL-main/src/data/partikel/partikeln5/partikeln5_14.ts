import { Particle } from "../../../types";

export const partikeln5_14: Particle[] = [
  // Tambahkan partikel lainnya
];