import { Particle } from "../../../types";

export const partikeln5_3: Particle[] = [
  { 
    char: 'の (No)', 
    usage: 'Kepemilikan / Modifikasi', 
    explanation: 'Menghubungkan dua kata benda. Sering berarti "milik", "buatan", atau "tentang". KB1 menerangkan KB2.', 
    example: '私の本 (Buku saya).', 
    level: 'N5',
    examples: [
      { japanese: 'これは私の傘です。', romaji: 'Kore wa watashi no kasa desu.', meaning: 'Ini adalah payung saya.' },
      { japanese: '日本語の本を読みます。', romaji: 'Nihongo no hon o yomimasu.', meaning: 'Membaca buku bahasa Jepang.' },
      { japanese: '東京の天気はどうですか。', romaji: 'Toukyou no tenki wa dou desu ka.', meaning: 'Bagaimana cuaca di Tokyo?' },
      { japanese: 'あの人は会社の社長です。', romaji: 'Ano hito wa kaisha no shachou desu.', meaning: 'Orang itu adalah presiden direktur perusahaan.' },
      { japanese: 'それはどこの靴ですか。', romaji: 'Sore wa doko no kutsu desu ka.', meaning: 'Itu sepatu buatan mana?' }
    ]
  },
  { 
    char: 'と (To)', 
    usage: 'Dan (Lengkap)', 
    explanation: 'Digunakan untuk menghubungkan kata benda secara setara. Nuansanya menyebutkan semua item secara lengkap.', 
    example: 'ペンとノートを買いました (Membeli pena dan buku catatan).', 
    level: 'N5',
    examples: [
      { japanese: '肉と野菜を食べます。', romaji: 'Niku to yasai o tabemasu.', meaning: 'Makan daging dan sayur.' },
      { japanese: 'これとそれをください。', romaji: 'Kore to sore o kudasai.', meaning: 'Tolong berikan ini dan itu.' },
      { japanese: '父と母は元気です。', romaji: 'Chichi to haha wa genki desu.', meaning: 'Ayah dan ibu sehat.' },
      { japanese: '時計と眼鏡を忘れました。', romaji: 'Tokei to megane o wasuremashita.', meaning: 'Saya lupa jam tangan dan kacamata.' },
      { japanese: '春と秋が好きです。', romaji: 'Haru to aki ga suki desu.', meaning: 'Saya suka musim semi dan musim gugur.' }
    ]
  },
  { 
    char: 'と (To)', 
    usage: 'Bersama (Dengan)', 
    explanation: 'Menunjukkan orang/hewan yang menemani melakukan aktivitas.', 
    example: '友達と遊びます (Bermain bersama teman).', 
    level: 'N5',
    examples: [
      { japanese: '週末、友達と映画を見ました。', romaji: 'Shuumatsu, tomodachi to eiga o mimashita.', meaning: 'Akhir pekan saya menonton film bersama teman.' },
      { japanese: '誰と行きますか。', romaji: 'Dare to ikimasu ka.', meaning: 'Pergi dengan siapa?' },
      { japanese: '家族と食事します。', romaji: 'Kazoku to shokuji shimasu.', meaning: 'Makan bersama keluarga.' },
      { japanese: '恋人とデートします。', romaji: 'Koibito to de-to shimasu.', meaning: 'Kencan dengan pacar.' },
      { japanese: '一人で勉強します (Tanpa To)。', romaji: 'Hitori de benkyou shimasu.', meaning: 'Belajar sendirian (Pengecualian, pakai De).' }
    ]
  },
  { 
    char: 'や (Ya)', 
    usage: 'Dan (Sebagian)', 
    explanation: 'Menyebutkan contoh sebagian benda dari kelompok yang lebih besar. Sering diikuti "nado" (dll).', 
    example: '机の上に本やペンがあります (Di meja ada buku, pena, dll).', 
    level: 'N5',
    examples: [
      { japanese: '箱の中にリンゴやミカンがあります。', romaji: 'Hako no naka ni ringo ya mikan ga arimasu.', meaning: 'Di dalam kotak ada apel, jeruk, dll.' },
      { japanese: '私の趣味はテニスや水泳です。', romaji: 'Watashi no shumi wa tenisu ya suiei desu.', meaning: 'Hobi saya tenis, renang, dan lainnya.' },
      { japanese: '休みの日には、掃除や洗濯をします。', romaji: 'Yasumi no hi ni wa, souji ya sentaku o shimasu.', meaning: 'Di hari libur, saya bersih-bersih, mencuci, dll.' },
      { japanese: '部屋にテレビやベッドがあります。', romaji: 'Heya ni terebi ya beddo ga arimasu.', meaning: 'Di kamar ada TV, kasur, dsb.' },
      { japanese: '動物園でパンダやライオンを見ました。', romaji: 'Doubutsuen de panda ya raion o mimashita.', meaning: 'Di kebun binatang saya melihat panda, singa, dll.' }
    ]
  },
  { 
    char: 'か (Ka)', 
    usage: 'Atau / Pilihan', 
    explanation: 'Menunjukkan pilihan antara dua hal atau lebih.', 
    example: 'コーヒーか紅茶を飲みます (Minum kopi atau teh).', 
    level: 'N5',
    examples: [
      { japanese: '今日か明日、電話します。', romaji: 'Kyou ka ashita, denwa shimasu.', meaning: 'Hari ini atau besok, saya akan menelepon.' },
      { japanese: 'バスかタクシーで行きましょう。', romaji: 'Basu ka takushii de ikimashou.', meaning: 'Ayo pergi naik bus atau taksi.' },
      { japanese: '青か赤が好きです。', romaji: 'Ao ka aka ga suki desu.', meaning: 'Saya suka biru atau merah.' },
      { japanese: '右か左かわかりません。', romaji: 'Migi ka hidari ka wakarimasen.', meaning: 'Saya tidak tahu kanan atau kiri.' },
      { japanese: '肉か魚、どちらがいいですか。', romaji: 'Niku ka sakana, dochira ga ii desu ka.', meaning: 'Daging atau ikan, mana yang lebih baik?' }
    ]
  },
  { 
    char: 'か (Ka)', 
    usage: 'Tanda Tanya', 
    explanation: 'Diletakkan di akhir kalimat untuk mengubahnya menjadi kalimat tanya.', 
    example: 'これは何ですか (Ini apa?).', 
    level: 'N5',
    examples: [
      { japanese: 'お元気ですか。', romaji: 'Ogenki desu ka.', meaning: 'Apa kabar?' },
      { japanese: '今、何時ですか。', romaji: 'Ima, nanji desu ka.', meaning: 'Sekarang jam berapa?' },
      { japanese: 'わかりましたか。', romaji: 'Wakarimashita ka.', meaning: 'Apakah sudah mengerti?' },
      { japanese: 'そうですか。', romaji: 'Sou desu ka.', meaning: 'Begitu ya?' },
      { japanese: 'だれですか。', romaji: 'Dare desu ka.', meaning: 'Siapa itu?' }
    ]
  }
];