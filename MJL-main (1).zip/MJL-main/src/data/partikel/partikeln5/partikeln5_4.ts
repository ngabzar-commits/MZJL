import { Particle } from "../../../types";

export const partikeln5_4: Particle[] = [
  { 
    char: 'も (Mo)', 
    usage: 'Juga / Pun', 
    explanation: 'Menggantikan partikel "wa", "ga", atau "o" untuk menunjukkan kesamaan dengan hal yang disebutkan sebelumnya.', 
    example: '私も学生です (Saya juga siswa).', 
    level: 'N5',
    examples: [
      { japanese: 'あの方も日本人です。', romaji: 'Ano kata mo Nihonjin desu.', meaning: 'Beliau itu juga orang Jepang.' },
      { japanese: 'これもください。', romaji: 'Kore mo kudasai.', meaning: 'Tolong yang ini juga.' },
      { japanese: '昨日も雨でした。', romaji: 'Kinou mo ame deshita.', meaning: 'Kemarin juga hujan.' },
      { japanese: '英語も話せます。', romaji: 'Eigo mo hanasemasu.', meaning: 'Bahasa Inggris pun saya bisa.' },
      { japanese: 'コーヒーが好きです。紅茶も好きです。', romaji: 'Ko-hi- ga suki desu. Koucha mo suki desu.', meaning: 'Saya suka kopi. Teh juga suka.' }
    ]
  },
  { 
    char: 'から (Kara)', 
    usage: 'Titik Awal (Dari)', 
    explanation: 'Menunjukkan titik permulaan waktu atau tempat.', 
    example: '9時から働きます (Bekerja dari jam 9).', 
    level: 'N5',
    examples: [
      { japanese: '会議は１時から始まります。', romaji: 'Kaigi wa ichiji kara hajimarimasu.', meaning: 'Rapat dimulai dari jam 1.' },
      { japanese: 'ここから駅まで近いです。', romaji: 'Koko kara eki made chikai desu.', meaning: 'Dari sini sampai stasiun dekat.' },
      { japanese: '大阪から来ました。', romaji: 'Oosaka kara kimashita.', meaning: 'Saya datang dari Osaka.' },
      { japanese: '何時からですか。', romaji: 'Nanji kara desu ka.', meaning: 'Dari jam berapa?' },
      { japanese: '月曜日から金曜日まで働きます。', romaji: 'Getsuyoubi kara kinyoubi made hatarakimasu.', meaning: 'Bekerja dari Senin sampai Jumat.' }
    ]
  },
  { 
    char: 'から (Kara)', 
    usage: 'Alasan (Karena)', 
    explanation: 'Diletakkan di akhir kalimat penyebab untuk menyatakan alasan.', 
    example: '暑いですから、窓を開けます (Karena panas, saya buka jendela).', 
    level: 'N5',
    examples: [
      { japanese: '時間がないから、タクシーで行きましょう。', romaji: 'Jikan ga nai kara, takushii de ikimashou.', meaning: 'Karena tidak ada waktu, ayo pergi naik taksi.' },
      { japanese: '危ないですから、触らないでください。', romaji: 'Abunai desu kara, sawaranaide kudasai.', meaning: 'Karena berbahaya, tolong jangan disentuh.' },
      { japanese: '高いですから、買いません。', romaji: 'Takai desu kara, kaimasen.', meaning: 'Karena mahal, saya tidak beli.' },
      { japanese: '好きだから、毎日食べます。', romaji: 'Suki dakara, mainichi tabemasu.', meaning: 'Karena suka, saya makan setiap hari.' },
      { japanese: '雨だから、出かけません。', romaji: 'Ame dakara, dekakemasen.', meaning: 'Karena hujan, saya tidak keluar.' }
    ]
  },
  { 
    char: 'まで (Made)', 
    usage: 'Batas Akhir (Sampai)', 
    explanation: 'Menunjukkan titik akhir waktu atau tempat.', 
    example: '5時まで勉強します (Belajar sampai jam 5).', 
    level: 'N5',
    examples: [
      { japanese: '駅まで歩きます。', romaji: 'Eki made arukimasu.', meaning: 'Berjalan sampai stasiun.' },
      { japanese: '昼休みは１時までです。', romaji: 'Hiruyasumi wa ichiji made desu.', meaning: 'Istirahat siang sampai jam 1.' },
      { japanese: '東京までどのぐらいかかりますか。', romaji: 'Toukyou made dono gurai kakarimasu ka.', meaning: 'Sampai Tokyo memakan waktu berapa lama?' },
      { japanese: '朝まで寝ませんでした。', romaji: 'Asa made nemasen deshita.', meaning: 'Saya tidak tidur sampai pagi.' },
      { japanese: 'ここまでお願いします。', romaji: 'Koko made onegaishimasu.', meaning: 'Tolong antar sampai sini.' }
    ]
  }
];