
import { Particle } from "../../../types";

export const partikeln2_17: Particle[] = [
  // Akan diisi lebih lanjut
];
