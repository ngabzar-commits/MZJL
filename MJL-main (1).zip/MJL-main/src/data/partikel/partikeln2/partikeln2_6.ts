
import { Particle } from "../../../types";

export const partikeln2_6: Particle[] = [
  // Akan diisi lebih lanjut
];
