
import { Particle } from "../../../types";

export const partikeln2_12: Particle[] = [
  // Akan diisi lebih lanjut
];
