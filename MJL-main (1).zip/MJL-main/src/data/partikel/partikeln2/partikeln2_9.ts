
import { Particle } from "../../../types";

export const partikeln2_9: Particle[] = [
  // Akan diisi lebih lanjut
];
