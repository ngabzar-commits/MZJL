
import { Particle } from "../../../types";

export const partikeln2_16: Particle[] = [
  // Akan diisi lebih lanjut
];
