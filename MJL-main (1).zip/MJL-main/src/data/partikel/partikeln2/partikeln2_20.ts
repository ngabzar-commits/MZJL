
import { Particle } from "../../../types";

export const partikeln2_20: Particle[] = [
  // Akan diisi lebih lanjut
];
