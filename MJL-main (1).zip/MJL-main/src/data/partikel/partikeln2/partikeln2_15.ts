
import { Particle } from "../../../types";

export const partikeln2_15: Particle[] = [
  // Akan diisi lebih lanjut
];
