
import { Particle } from "../../../types";

export const partikeln2_8: Particle[] = [
  // Akan diisi lebih lanjut
];
