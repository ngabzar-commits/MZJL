
import { Particle } from "../../../types";

export const partikeln2_14: Particle[] = [
  // Akan diisi lebih lanjut
];
