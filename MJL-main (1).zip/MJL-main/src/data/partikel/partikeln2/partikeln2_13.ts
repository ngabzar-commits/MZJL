
import { Particle } from "../../../types";

export const partikeln2_13: Particle[] = [
  // Akan diisi lebih lanjut
];
