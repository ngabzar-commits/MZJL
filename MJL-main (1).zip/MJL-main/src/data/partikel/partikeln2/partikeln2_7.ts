
import { Particle } from "../../../types";

export const partikeln2_7: Particle[] = [
  // Akan diisi lebih lanjut
];
