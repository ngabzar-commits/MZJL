
import { Particle } from "../../../types";

export const partikeln2_10: Particle[] = [
  // Akan diisi lebih lanjut
];
