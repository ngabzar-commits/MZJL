import { Grammar } from "../../../types";

export const bunpoun5_16: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];