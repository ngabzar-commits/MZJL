import { Grammar } from "../../../types";

export const bunpoun5_9: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];