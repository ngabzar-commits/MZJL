import { Grammar } from "../../../types";

export const bunpoun5_10: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];