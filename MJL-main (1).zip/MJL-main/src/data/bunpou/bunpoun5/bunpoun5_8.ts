import { Grammar } from "../../../types";

export const bunpoun5_8: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];