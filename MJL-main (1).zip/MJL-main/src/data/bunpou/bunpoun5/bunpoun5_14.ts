import { Grammar } from "../../../types";

export const bunpoun5_14: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];