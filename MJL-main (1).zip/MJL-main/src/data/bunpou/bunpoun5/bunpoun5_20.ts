import { Grammar } from "../../../types";

export const bunpoun5_20: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];