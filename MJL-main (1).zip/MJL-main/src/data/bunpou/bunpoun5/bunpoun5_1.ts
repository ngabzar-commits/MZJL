import { Grammar } from "../../../types";

export const bunpoun5_1: Grammar[] = [
  { 
    title: '~は ~です (Wa ... Desu)', 
    formula: 'Subjek + は + Predikat + です', 
    explanation: 'Pola kalimat paling dasar dalam bahasa Jepang. Partikel "Wa" (ditulis Ha) menandakan topik kalimat, sedangkan "Desu" adalah kopula sopan yang mengakhiri kalimat positif.', 
    level: 'N5',
    examples: [
      { japanese: '私は学生です。', romaji: 'Watashi wa gakusei desu.', meaning: 'Saya adalah seorang siswa.' },
      { japanese: '山田さんは先生です。', romaji: 'Yamada-san wa sensei desu.', meaning: 'Sdr. Yamada adalah seorang guru.' },
      { japanese: 'これはペンです。', romaji: 'Kore wa pen desu.', meaning: 'Ini adalah pena.' },
      { japanese: '父は医者です。', romaji: 'Chichi wa isha desu.', meaning: 'Ayah saya adalah dokter.' },
      { japanese: 'ここは東京です。', romaji: 'Koko wa Toukyou desu.', meaning: 'Di sini adalah Tokyo.' }
    ]
  },
  { 
    title: '~ます (Masu)', 
    formula: 'KK(Bentuk Masu) + ます', 
    explanation: 'Bentuk sopan untuk kata kerja positif non-lampau. Digunakan untuk menyatakan kebiasaan atau hal yang akan terjadi di masa depan.', 
    level: 'N5',
    examples: [
      { japanese: '毎日、コーヒーを飲みます。', romaji: 'Mainichi, ko-hi- o nomimasu.', meaning: 'Setiap hari saya minum kopi.' },
      { japanese: '明日、東京へ行きます。', romaji: 'Ashita, Toukyou e ikimasu.', meaning: 'Besok saya akan pergi ke Tokyo.' },
      { japanese: '毎晩、テレビを見ます。', romaji: 'Maiban, terebi o mimasu.', meaning: 'Setiap malam saya menonton TV.' },
      { japanese: '朝、６時に起きます。', romaji: 'Asa, rokuji ni okimasu.', meaning: 'Pagi hari saya bangun jam 6.' },
      { japanese: '日本語を勉強します。', romaji: 'Nihongo o benkyou shimasu.', meaning: 'Saya belajar bahasa Jepang.' }
    ]
  },
  { 
    title: '~ません (Masen)', 
    formula: 'KK(Bentuk Masu) + ません', 
    explanation: 'Bentuk negatif sopan untuk kata kerja. Digunakan untuk menyatakan "tidak melakukan" sesuatu.', 
    level: 'N5',
    examples: [
      { japanese: '私は肉を食べません。', romaji: 'Watashi wa niku o tabemasen.', meaning: 'Saya tidak makan daging.' },
      { japanese: '明日は働きません。', romaji: 'Ashita wa hatarakimasen.', meaning: 'Besok saya tidak bekerja.' },
      { japanese: 'お酒を飲みません。', romaji: 'Osake o nomimasen.', meaning: 'Saya tidak minum alkohol.' },
      { japanese: '英語がわかりません。', romaji: 'Eigo ga wakarimasen.', meaning: 'Saya tidak mengerti bahasa Inggris.' },
      { japanese: 'どこへも行きません。', romaji: 'Doko e mo ikimasen.', meaning: 'Saya tidak pergi kemana-mana.' }
    ]
  },
  { 
    title: '~ました (Mashita)', 
    formula: 'KK(Bentuk Masu) + ました', 
    explanation: 'Bentuk lampau sopan untuk kata kerja. Digunakan untuk menyatakan kegiatan yang "sudah" dilakukan.', 
    level: 'N5',
    examples: [
      { japanese: '昨日、勉強しました。', romaji: 'Kinou, benkyou shimashita.', meaning: 'Kemarin saya sudah belajar.' },
      { japanese: '先週、映画を見ました。', romaji: 'Senshuu, eiga o mimashita.', meaning: 'Minggu lalu saya menonton film.' },
      { japanese: '今朝、パンを食べました。', romaji: 'Kesa, pan o tabemashita.', meaning: 'Tadi pagi saya makan roti.' },
      { japanese: '手紙を書きました。', romaji: 'Tegami o kakimashita.', meaning: 'Saya sudah menulis surat.' },
      { japanese: '友達に会いました。', romaji: 'Tomodachi ni aimashita.', meaning: 'Saya sudah bertemu teman.' }
    ]
  },
  { 
    title: '~も (Mo)', 
    formula: 'KB + も', 
    explanation: 'Partikel yang berarti "juga" atau "pun". Menggantikan partikel "wa" atau "ga" jika predikatnya sama dengan kalimat sebelumnya.', 
    level: 'N5',
    examples: [
      { japanese: '私も学生です。', romaji: 'Watashi mo gakusei desu.', meaning: 'Saya juga seorang siswa.' },
      { japanese: 'これも美味しいです。', romaji: 'Kore mo oishii desu.', meaning: 'Ini juga enak.' },
      { japanese: '田中さんも来ました。', romaji: 'Tanaka-san mo kimashita.', meaning: 'Sdr. Tanaka juga datang.' },
      { japanese: '昨日も雨でした。', romaji: 'Kinou mo ame deshita.', meaning: 'Kemarin juga hujan.' },
      { japanese: '英語も話せます。', romaji: 'Eigo mo hanasemasu.', meaning: 'Saya juga bisa bicara bahasa Inggris.' }
    ]
  },
  { 
    title: '~を (O)', 
    formula: 'KB(Objek) + を + KK(Transitif)', 
    explanation: 'Partikel penanda objek penderita. Menunjukkan benda yang dikenai tindakan oleh kata kerja.', 
    level: 'N5',
    examples: [
      { japanese: '本を読みます。', romaji: 'Hon o yomimasu.', meaning: 'Membaca buku.' },
      { japanese: 'ご飯を食べます。', romaji: 'Gohan o tabemasu.', meaning: 'Makan nasi.' },
      { japanese: '音楽を聞きます。', romaji: 'Ongaku o kikimasu.', meaning: 'Mendengarkan musik.' },
      { japanese: '写真を撮ります。', romaji: 'Shashin o torimasu.', meaning: 'Mengambil foto.' },
      { japanese: '水を飲みます。', romaji: 'Mizu o nomimasu.', meaning: 'Minum air.' }
    ]
  },
  { 
    title: '~で (De) - Tempat', 
    formula: 'Tempat + で + KK(Aksi)', 
    explanation: 'Menandai tempat terjadinya suatu aktivitas atau aksi.', 
    level: 'N5',
    examples: [
      { japanese: '図書館で勉強します。', romaji: 'Toshokan de benkyou shimasu.', meaning: 'Belajar di perpustakaan.' },
      { japanese: '食堂で昼ご飯を食べます。', romaji: 'Shokudou de hirugohan o tabemasu.', meaning: 'Makan siang di kantin.' },
      { japanese: '駅で新聞を買いました。', romaji: 'Eki de shinbun o kaimashita.', meaning: 'Membeli koran di stasiun.' },
      { japanese: '部屋で寝ます。', romaji: 'Heya de nemasu.', meaning: 'Tidur di kamar.' },
      { japanese: '日本で働きたいです。', romaji: 'Nihon de hatarakitai desu.', meaning: 'Saya ingin bekerja di Jepang.' }
    ]
  },
  { 
    title: '~に/へ (Ni/He) - Arah', 
    formula: 'Tempat + に/へ + 行きます/来ます/帰ります', 
    explanation: 'Menandai tujuan pergerakan. "He" (dibaca e) lebih menekankan arah, "Ni" menekankan titik tujuan.', 
    level: 'N5',
    examples: [
      { japanese: '日本へ行きます。', romaji: 'Nihon e ikimasu.', meaning: 'Pergi ke Jepang.' },
      { japanese: '家へ帰ります。', romaji: 'Uchi e kaerimasu.', meaning: 'Pulang ke rumah.' },
      { japanese: '学校に来ました。', romaji: 'Gakkou ni kimashita.', meaning: 'Datang ke sekolah.' },
      { japanese: 'どこへ行きますか。', romaji: 'Doko e ikimasu ka.', meaning: 'Mau pergi ke mana?' },
      { japanese: '京都へ旅行します。', romaji: 'Kyouto e ryokou shimasu.', meaning: 'Traveling ke Kyoto.' }
    ]
  }
];