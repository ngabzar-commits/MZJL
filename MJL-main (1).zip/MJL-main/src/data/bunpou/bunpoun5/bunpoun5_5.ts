import { Grammar } from "../../../types";

export const bunpoun5_5: Grammar[] = [
  { 
    title: '~てください (Te kudasai)', 
    formula: 'KK(Bentuk Te) + ください', 
    explanation: 'Meminta tolong atau mempersilakan dengan sopan.', 
    example: '日本語を教えてください (Tolong ajarkan bahasa Jepang).', 
    level: 'N5' 
  },
  { 
    title: '~ています (Te imasu) - Sedang', 
    formula: 'KK(Bentuk Te) + います', 
    explanation: 'Menyatakan aksi yang sedang berlangsung (Continuous).', 
    example: '今、ご飯を食べています (Sekarang sedang makan nasi).', 
    level: 'N5' 
  },
  { 
    title: '~ています (Te imasu) - Status', 
    formula: 'KK(Bentuk Te) + います', 
    explanation: 'Menyatakan keadaan/status yang berlanjut (misal: menikah, tinggal, punya).', 
    example: '東京に住んでいます (Tinggal di Tokyo).', 
    level: 'N5' 
  },
  { 
    title: '~てもいいですか (Te mo ii desu ka)', 
    formula: 'KK(Bentuk Te) + もいいですか', 
    explanation: 'Meminta izin melakukan sesuatu.', 
    example: '写真を撮ってもいいですか (Bolehkah mengambil foto?).', 
    level: 'N5' 
  },
  { 
    title: '~てはいけません (Te wa ikemasen)', 
    formula: 'KK(Bentuk Te) + はいけません', 
    explanation: 'Larangan melakukan sesuatu (Tidak boleh).', 
    example: 'ここでタバコを吸ってはいけません (Tidak boleh merokok di sini).', 
    level: 'N5' 
  },
  { 
    title: 'Menggabungkan Kalimat (Te)', 
    formula: 'Kalimat 1 (Te), Kalimat 2', 
    explanation: 'Menggunakan bentuk Te untuk menyambung kalimat (dan/lalu).', 
    example: '朝起きて、朝ご飯を食べます (Bangun pagi, lalu sarapan).', 
    level: 'N5' 
  }
];