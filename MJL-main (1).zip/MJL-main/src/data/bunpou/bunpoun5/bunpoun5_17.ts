import { Grammar } from "../../../types";

export const bunpoun5_17: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];