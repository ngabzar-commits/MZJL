import { Grammar } from "../../../types";

export const bunpoun5_19: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];