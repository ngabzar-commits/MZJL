
import { Grammar } from "../../../types";

export const bunpoun1_19: Grammar[] = [
  // Akan diisi lebih lanjut
];
