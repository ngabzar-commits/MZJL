
import { Grammar } from "../../../types";

export const bunpoun1_14: Grammar[] = [
  // Akan diisi lebih lanjut
];
