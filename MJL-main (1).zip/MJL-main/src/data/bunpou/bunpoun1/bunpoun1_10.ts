
import { Grammar } from "../../../types";

export const bunpoun1_10: Grammar[] = [
  // Akan diisi lebih lanjut
];
