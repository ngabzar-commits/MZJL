
import { Grammar } from "../../../types";

export const bunpoun1_18: Grammar[] = [
  // Akan diisi lebih lanjut
];
