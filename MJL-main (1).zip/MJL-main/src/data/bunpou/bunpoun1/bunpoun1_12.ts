
import { Grammar } from "../../../types";

export const bunpoun1_12: Grammar[] = [
  // Akan diisi lebih lanjut
];
