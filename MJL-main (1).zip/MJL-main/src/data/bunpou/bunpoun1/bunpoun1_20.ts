
import { Grammar } from "../../../types";

export const bunpoun1_20: Grammar[] = [
  // Akan diisi lebih lanjut
];
