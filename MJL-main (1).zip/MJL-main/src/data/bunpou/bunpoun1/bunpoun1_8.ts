
import { Grammar } from "../../../types";

export const bunpoun1_8: Grammar[] = [
  // Akan diisi lebih lanjut
];
