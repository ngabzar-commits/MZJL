
import { Grammar } from "../../../types";

export const bunpoun1_16: Grammar[] = [
  // Akan diisi lebih lanjut
];
