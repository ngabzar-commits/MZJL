
import { Grammar } from "../../../types";

export const bunpoun1_15: Grammar[] = [
  // Akan diisi lebih lanjut
];
