
import { Grammar } from "../../../types";

export const bunpoun1_6: Grammar[] = [
  // Akan diisi lebih lanjut
];
