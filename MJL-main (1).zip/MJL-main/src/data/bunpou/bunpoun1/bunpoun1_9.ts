
import { Grammar } from "../../../types";

export const bunpoun1_9: Grammar[] = [
  // Akan diisi lebih lanjut
];
