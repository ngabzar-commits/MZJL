
import { Grammar } from "../../../types";

export const bunpoun3_6: Grammar[] = [
  // Akan diisi lebih lanjut
];
