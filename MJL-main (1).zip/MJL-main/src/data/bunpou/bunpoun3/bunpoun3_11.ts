
import { Grammar } from "../../../types";

export const bunpoun3_11: Grammar[] = [
  // Akan diisi lebih lanjut
];
