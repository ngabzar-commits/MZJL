
import { Grammar } from "../../../types";

export const bunpoun3_7: Grammar[] = [
  // Akan diisi lebih lanjut
];
