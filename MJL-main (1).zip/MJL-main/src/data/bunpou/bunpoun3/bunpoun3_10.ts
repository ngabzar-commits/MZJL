
import { Grammar } from "../../../types";

export const bunpoun3_10: Grammar[] = [
  // Akan diisi lebih lanjut
];
