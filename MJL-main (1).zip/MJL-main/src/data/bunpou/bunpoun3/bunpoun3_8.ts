
import { Grammar } from "../../../types";

export const bunpoun3_8: Grammar[] = [
  // Akan diisi lebih lanjut
];
