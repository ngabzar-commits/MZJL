
import { Grammar } from "../../../types";

export const bunpoun3_9: Grammar[] = [
  // Akan diisi lebih lanjut
];
