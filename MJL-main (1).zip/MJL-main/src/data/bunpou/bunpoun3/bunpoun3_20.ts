
import { Grammar } from "../../../types";

export const bunpoun3_20: Grammar[] = [
  // Akan diisi lebih lanjut
];
