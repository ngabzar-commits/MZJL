
import { Grammar } from "../../../types";

export const bunpoun3_18: Grammar[] = [
  // Akan diisi lebih lanjut
];
