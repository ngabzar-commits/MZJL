
import { Grammar } from "../../../types";

export const bunpoun3_16: Grammar[] = [
  // Akan diisi lebih lanjut
];
