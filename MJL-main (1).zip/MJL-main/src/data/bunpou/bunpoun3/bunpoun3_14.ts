
import { Grammar } from "../../../types";

export const bunpoun3_14: Grammar[] = [
  // Akan diisi lebih lanjut
];
