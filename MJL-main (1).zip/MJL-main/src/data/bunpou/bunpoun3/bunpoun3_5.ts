
import { Grammar } from "../../../types";

export const bunpoun3_5: Grammar[] = [
  { 
    title: '~おかげで / ~おかげだ (Okage de)', 
    formula: 'Bentuk Biasa + おかげで', 
    explanation: 'Berkat... (Hasil positif).', 
    level: 'N3',
    examples: [
      { japanese: '先生のおかげで、合格できました。', romaji: 'Sensei no okage de, goukaku dekimashita.', meaning: 'Berkat guru, saya bisa lulus.' },
      { japanese: '天気がいいおかげで、景色がきれいです。', romaji: 'Tenki ga ii okage de, keshiki ga kirei desu.', meaning: 'Berkat cuaca bagus, pemandangannya indah.' },
      { japanese: '日本へ来たおかげで、日本語が上手になりました。', romaji: 'Nihon e kita okage de, Nihongo ga jouzu ni narimashita.', meaning: 'Berkat datang ke Jepang, bahasa Jepang saya jadi mahir.' }
    ]
  },
  { 
    title: '~せいで / ~せいだ (Sei de)', 
    formula: 'Bentuk Biasa + せいで', 
    explanation: 'Gara-gara... (Hasil negatif).', 
    level: 'N3',
    examples: [
      { japanese: 'バスが遅れたせいで、遅刻しました。', romaji: 'Basu ga okureta sei de, chikoku shimashita.', meaning: 'Gara-gara bus terlambat, saya jadi telat.' },
      { japanese: '甘い物を食べ過ぎたせいで、太ってしまいました。', romaji: 'Amai mono o tabesugita sei de, futotte shimaimashita.', meaning: 'Gara-gara terlalu banyak makan manis, saya jadi gendut.' },
      { japanese: 'あなたのせいです。', romaji: 'Anata no sei desu.', meaning: 'Ini salahmu (gara-gara kamu).' }
    ]
  },
  { 
    title: '~のだ / ~んだ (No da / N da)', 
    formula: 'Bentuk Biasa + のだ・んだ', 
    explanation: 'Penjelasan alasan, penekanan, atau kesimpulan.', 
    level: 'N3',
    examples: [
      { japanese: 'どうして遅れたのですか。－電車が来なかったんです。', romaji: 'Doushite okureta no desu ka. - Densha ga konakattan desu.', meaning: 'Kenapa terlambat? - (Soalnya) keretanya tidak datang.' },
      { japanese: 'すごい！君が作ったんだね。', romaji: 'Sugoi! Kimi ga tsukuttan da ne.', meaning: 'Hebat! Kamu yang buat ya.' }
    ]
  },
  { 
    title: '~（の）なら (No nara)', 
    formula: 'Bentuk Biasa + （の）なら', 
    explanation: 'Kalau memang begitu... (Berdasarkan info lawan bicara).', 
    level: 'N3',
    examples: [
      { japanese: '明日雨なら、ハイキングは中止です。', romaji: 'Ashita ame nara, haikingu wa chuushi desu.', meaning: 'Kalau besok hujan, hiking dibatalkan.' },
      { japanese: '彼が行くなら、私も行きます。', romaji: 'Kare ga iku nara, watashi mo ikimasu.', meaning: 'Kalau dia pergi, saya juga pergi.' },
      { japanese: '嫌なら、しなくてもいいですよ。', romaji: 'Iya nara, shinakutemo ii desu yo.', meaning: 'Kalau tidak suka, tidak usah dilakukan.' }
    ]
  },
  { 
    title: '~ては / ~では (Te wa / De wa)', 
    formula: 'KK(Te) + は', 
    explanation: 'Kalau... (akan terjadi hal buruk). Biasanya diikuti konsekuensi negatif.', 
    level: 'N3',
    examples: [
      { japanese: 'そんなに食べては、太りますよ。', romaji: 'Sonna ni tabete wa, futorimasu yo.', meaning: 'Kalau makan sebanyak itu, bakal gendut lho.' },
      { japanese: '遊んでばかりいては、試験に合格できません。', romaji: 'Asonde bakari ite wa, shiken ni goukaku dekimasen.', meaning: 'Kalau main melulu, tidak bisa lulus ujian.' },
      { japanese: 'ここでは騒いではいけません。', romaji: 'Koko de sawaide wa ikemasen.', meaning: 'Tidak boleh ribut di sini.' }
    ]
  }
];
