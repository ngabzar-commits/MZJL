
import { Grammar } from "../../../types";

export const bunpoun3_12: Grammar[] = [
  // Akan diisi lebih lanjut
];
