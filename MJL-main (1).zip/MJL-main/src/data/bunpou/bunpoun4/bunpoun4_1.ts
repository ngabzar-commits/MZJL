import { Grammar } from "../../../types";

export const bunpoun4_1: Grammar[] = [
  { 
    title: '~ことができます (Koto ga dekimasu)', 
    formula: 'KK(Bentuk Kamus) + ことができます', 
    explanation: 'Menyatakan kemampuan melakukan sesuatu (Bisa/Dapat). Mengubah kata kerja menjadi kata benda menggunakan "koto" lalu menambahkan "ga dekimasu".', 
    level: 'N4',
    examples: [
      { japanese: '漢字を書くことができます。', romaji: 'Kanji o kaku koto ga dekimasu.', meaning: 'Saya bisa menulis Kanji.' },
      { japanese: 'ピアノを弾くことができます。', romaji: 'Piano o hiku koto ga dekimasu.', meaning: 'Saya bisa bermain piano.' },
      { japanese: 'ここでタバコを吸うことはできません。', romaji: 'Koko de tabako o suu koto wa dekimasen.', meaning: 'Di sini tidak bisa (tidak boleh) merokok.' },
      { japanese: '車を運転することができますか。', romaji: 'Kuruma o unten suru koto ga dekimasu ka.', meaning: 'Apakah kamu bisa menyetir mobil?' },
      { japanese: 'カードで払うことができます。', romaji: 'Ka-do de harau koto ga dekimasu.', meaning: 'Bisa membayar menggunakan kartu.' }
    ]
  },
  { 
    title: 'Kata Kerja Potensial (Kanoukei)', 
    formula: 'Gol 1: u -> eru | Gol 2: ru -> rareru | Gol 3: kuru->korareru, suru->dekiru', 
    explanation: 'Perubahan kata kerja menjadi bentuk "Bisa". Partikel "o" pada kalimat asli biasanya berubah menjadi "ga" dalam bentuk potensial.', 
    level: 'N4',
    examples: [
      { japanese: '私は日本語が話せます。', romaji: 'Watashi wa Nihongo ga hanasemasu.', meaning: 'Saya bisa berbicara bahasa Jepang.' },
      { japanese: '明日、パーティーに行けます。', romaji: 'Ashita, pa-ti- ni ikemasu.', meaning: 'Besok saya bisa pergi ke pesta.' },
      { japanese: '生の魚が食べられません。', romaji: 'Nama no sakana ga taberaremasen.', meaning: 'Saya tidak bisa makan ikan mentah.' },
      { japanese: '漢字が読めますか。', romaji: 'Kanji ga yomemasu ka.', meaning: 'Apakah kamu bisa membaca Kanji?' },
      { japanese: '一人で着物が着られます。', romaji: 'Hitori de kimono ga kiraremasu.', meaning: 'Saya bisa memakai kimono sendiri.' }
    ]
  },
  { 
    title: '~が見えます/聞こえます (Miemasu/Kikoemasu)', 
    formula: 'Benda + が + 見えます/聞こえます', 
    explanation: 'Menyatakan sesuatu terlihat atau terdengar secara alami (spontan), bukan karena sengaja melihat/mendengar. "Miemasu" (Terlihat), "Kikoemasu" (Terdengar).', 
    level: 'N4',
    examples: [
      { japanese: 'ここから富士山が見えます。', romaji: 'Koko kara Fujisan ga miemasu.', meaning: 'Dari sini terlihat Gunung Fuji.' },
      { japanese: '鳥の声が聞こえます。', romaji: 'Tori no koe ga kikoemasu.', meaning: 'Terdengar suara burung.' },
      { japanese: '海が見えるホテルに泊まりたいです。', romaji: 'Umi ga mieru hoteru ni tomaritai desu.', meaning: 'Saya ingin menginap di hotel yang terlihat lautnya.' },
      { japanese: '変な音が聞こえました。', romaji: 'Hen na oto ga kikoemashita.', meaning: 'Terdengar suara aneh.' },
      { japanese: '眼鏡がないので、よく見えません。', romaji: 'Megane ga nai node, yoku miemasen.', meaning: 'Karena tidak ada kacamata, tidak terlihat jelas.' }
    ]
  }
];