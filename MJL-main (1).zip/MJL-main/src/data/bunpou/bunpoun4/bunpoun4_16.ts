import { Grammar } from "../../../types";

export const bunpoun4_16: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];