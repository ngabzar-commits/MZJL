import { Grammar } from "../../../types";

export const bunpoun4_14: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];