import { Grammar } from "../../../types";

export const bunpoun4_8: Grammar[] = [
  { 
    title: 'Transitif (Tadoushi)', 
    formula: 'Subjek + が + Objek + を + KK(Transitif)', 
    explanation: 'Kata kerja yang butuh objek (Seseorang melakukan sesuatu).', 
    example: 'ドアを開けました (Saya membuka pintu).', 
    level: 'N4' 
  },
  { 
    title: 'Intransitif (Jidoushi)', 
    formula: 'Subjek + が + KK(Intransitif)', 
    explanation: 'Kata kerja yang fokus pada keadaan subjek (Sesuatu terjadi).', 
    example: 'ドアが開きました (Pintu terbuka).', 
    level: 'N4' 
  },
  { 
    title: '~てあります (Te arimasu)', 
    formula: 'KK(Transitif-Te) + あります', 
    explanation: 'Menyatakan hasil dari aksi yang dilakukan seseorang (sengaja).', 
    example: '壁に絵が掛けてあります (Gambar terpajang di dinding - seseorang memajangnya).', 
    level: 'N4' 
  },
  { 
    title: '~ています (Te imasu) - Keadaan', 
    formula: 'KK(Intransitif-Te) + います', 
    explanation: 'Menyatakan keadaan hasil perubahan (otomatis).', 
    example: '電気がついています (Lampu menyala).', 
    level: 'N4' 
  },
  { 
    title: '~てしまう (Te shimau)', 
    formula: 'KK(Bentuk Te) + しまいます', 
    explanation: '1. Selesai tuntas. 2. Penyesalan (tidak sengaja).', 
    example: '宿題をやってしまいました (Sudah menyelesaikan PR). パスポートを忘れてしまいました (Kelupaan paspor - menyesal).', 
    level: 'N4' 
  }
];