import { Grammar } from "../../../types";

export const bunpoun4_10: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];