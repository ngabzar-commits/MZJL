import { Grammar } from "../../../types";

export const bunpoun4_11: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];