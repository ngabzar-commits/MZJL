import { Grammar } from "../../../types";

export const bunpoun4_18: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];