import { Grammar } from "../../../types";

export const bunpoun4_20: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];