import { Grammar } from "../../../types";

export const bunpoun4_13: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];