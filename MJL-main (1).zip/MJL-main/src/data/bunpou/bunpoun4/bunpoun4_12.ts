import { Grammar } from "../../../types";

export const bunpoun4_12: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];