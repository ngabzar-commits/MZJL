import { Grammar } from "../../../types";

export const bunpoun4_17: Grammar[] = [
  // Tambahkan tata bahasa lainnya
];