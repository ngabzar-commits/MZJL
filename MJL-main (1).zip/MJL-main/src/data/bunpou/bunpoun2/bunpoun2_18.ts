
import { Grammar } from "../../../types";

export const bunpoun2_18: Grammar[] = [
  // Akan diisi lebih lanjut
];
