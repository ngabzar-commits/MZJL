
import { Grammar } from "../../../types";

export const bunpoun2_9: Grammar[] = [
  // Akan diisi lebih lanjut
];
