
import { Grammar } from "../../../types";

export const bunpoun2_10: Grammar[] = [
  // Akan diisi lebih lanjut
];
