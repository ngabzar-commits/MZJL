
import { Grammar } from "../../../types";

export const bunpoun2_2: Grammar[] = [
  { 
    title: '~たとたん (Ta totan)', 
    formula: 'KK(Ta) + とたん（に）', 
    explanation: 'Segera setelah A, terjadi B (yang mengejutkan/di luar dugaan). Tidak digunakan untuk keinginan/perintah.', 
    level: 'N2',
    examples: [
      { japanese: '窓を開けたとたん、強い風が入ってきた。', romaji: 'Mado o aketa totan, tsuyoi kaze ga haitte kita.', meaning: 'Segera setelah membuka jendela, angin kencang masuk.' },
      { japanese: 'お酒を飲んだとたん、顔が赤くなった。', romaji: 'Osake o nonda totan, kao ga akaku natta.', meaning: 'Begitu minum alkohol, wajahnya langsung memerah.' },
      { japanese: '立ち上がったとたん、めまいがした。', romaji: 'Tachiagatta totan, memai ga shita.', meaning: 'Begitu berdiri, saya merasa pusing.' }
    ]
  },
  { 
    title: '~かと思うと (Ka to omou to)', 
    formula: 'KK(Ta) + かと思うと / かと思ったら', 
    explanation: 'Baru saja A terjadi, tiba-tiba langsung B terjadi. Menunjukkan perubahan yang cepat.', 
    level: 'N2',
    examples: [
      { japanese: '赤ちゃんは泣いたかと思うと、もう笑っている。', romaji: 'Akachan wa naita ka to omou to, mou waratte iru.', meaning: 'Bayi itu baru saja menangis, eh sekarang sudah tertawa.' },
      { japanese: 'やっと部屋が片付いたかと思ったら、子供がすぐに散らかした。', romaji: 'Yatto heya ga katazuita ka to omottara, kodomo ga sugu ni chirakashita.', meaning: 'Baru saja kamar dibereskan, anak-anak langsung mengantakannya lagi.' }
    ]
  },
  { 
    title: '~か~ないかのうちに (Ka nai ka no uchi ni)', 
    formula: 'KK(Kamus) + か + KK(Nai) + かのうちに', 
    explanation: 'Hampir bersamaan. A belum selesai sepenuhnya, tapi B sudah mulai.', 
    level: 'N2',
    examples: [
      { japanese: 'チャイムが鳴るか鳴らないかのうちに、先生が教室に入ってきた。', romaji: 'Chaimu ga naru ka naranai ka no uchi ni, sensei ga kyoushitsu ni haitte kita.', meaning: 'Bersamaan dengan bel berbunyi (bel belum selesai), guru sudah masuk kelas.' },
      { japanese: '布団に入るか入らないかのうちに、眠ってしまった。', romaji: 'Futon ni hairu ka hairanai ka no uchi ni, nemutte shimatta.', meaning: 'Baru saja masuk selimut (hampir belum), saya sudah tertidur.' }
    ]
  },
  { 
    title: '~次第 (Shidai)', 
    formula: 'KK(Masu-stem) + 次第', 
    explanation: 'Segera setelah A selesai, akan melakukan B. (Formal, menunjukkan niat).', 
    level: 'N2',
    examples: [
      { japanese: '決まり次第、ご連絡いたします。', romaji: 'Kimari shidai, gorenraku itashimasu.', meaning: 'Segera setelah diputuskan, saya akan menghubungi Anda.' },
      { japanese: '雨が止み次第、出発しましょう。', romaji: 'Ame ga yami shidai, shuppatsu shimashou.', meaning: 'Segera setelah hujan berhenti, ayo kita berangkat.' },
      { japanese: '詳しいことがわかり次第、お伝えします。', romaji: 'Kuwashii koto ga wakari shidai, otsutae shimasu.', meaning: 'Segera setelah detailnya diketahui, akan saya sampaikan.' }
    ]
  },
  { 
    title: '~て以来 (Te irai)', 
    formula: 'KK(Te) + 以来', 
    explanation: 'Semenjak A, keadaan B terus berlanjut sampai sekarang.', 
    level: 'N2',
    examples: [
      { japanese: '日本に来て以来、母の料理を食べていない。', romaji: 'Nihon ni kite irai, haha no ryouri o tabete inai.', meaning: 'Semenjak datang ke Jepang, saya belum makan masakan ibu.' },
      { japanese: '彼に会って以来、ずっと彼のことが好きだ。', romaji: 'Kare ni atte irai, zutto kare no koto ga suki da.', meaning: 'Semenjak bertemu dengannya, saya terus menyukainya.' },
      { japanese: '就職して以来、毎日忙しい。', romaji: 'Shuushoku shite irai, mainichi isogashii.', meaning: 'Semenjak mendapat pekerjaan, setiap hari sibuk.' }
    ]
  }
];
