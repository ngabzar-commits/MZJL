
import { Grammar } from "../../../types";

export const bunpoun2_8: Grammar[] = [
  // Akan diisi lebih lanjut
];
