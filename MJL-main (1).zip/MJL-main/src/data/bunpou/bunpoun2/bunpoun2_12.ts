
import { Grammar } from "../../../types";

export const bunpoun2_12: Grammar[] = [
  // Akan diisi lebih lanjut
];
