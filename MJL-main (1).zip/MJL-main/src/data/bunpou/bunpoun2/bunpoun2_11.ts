
import { Grammar } from "../../../types";

export const bunpoun2_11: Grammar[] = [
  // Akan diisi lebih lanjut
];
