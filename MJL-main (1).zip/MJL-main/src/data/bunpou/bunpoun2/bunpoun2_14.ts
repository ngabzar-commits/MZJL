
import { Grammar } from "../../../types";

export const bunpoun2_14: Grammar[] = [
  // Akan diisi lebih lanjut
];
