
import { Grammar } from "../../../types";

export const bunpoun2_17: Grammar[] = [
  // Akan diisi lebih lanjut
];
