
import { Grammar } from "../../../types";

export const bunpoun2_19: Grammar[] = [
  // Akan diisi lebih lanjut
];
