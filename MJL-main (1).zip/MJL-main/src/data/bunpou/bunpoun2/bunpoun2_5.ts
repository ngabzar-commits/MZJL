
import { Grammar } from "../../../types";

export const bunpoun2_5: Grammar[] = [
  { 
    title: '~こそ (Koso)', 
    formula: 'KB + こそ | ~から + こそ', 
    explanation: 'Justru... / Inilah yang... (Menekankan subjek/alasan dengan kuat).', 
    level: 'N2',
    examples: [
      { japanese: 'こちらこそ、よろしくお願いします。', romaji: 'Kochira koso, yoroshiku onegaishimasu.', meaning: 'Justru sayalah yang mohon bantuannya.' },
      { japanese: 'これこそ、私が探していた本だ。', romaji: 'Kore koso, watashi ga sagashite ita hon da.', meaning: 'Inilah (justru) buku yang selama ini saya cari.' },
      { japanese: '忙しいからこそ、時間を大切にしなければならない。', romaji: 'Isogashii kara koso, jikan o taisetsu ni shinakereba naranai.', meaning: 'Justru karena sibuk, kita harus menghargai waktu.' }
    ]
  },
  { 
    title: '~にしろ ~にしろ (Ni shiro... Ni shiro)', 
    formula: 'Bentuk Biasa + にしろ', 
    explanation: 'Baik A maupun B (hasilnya sama/harus dilakukan).', 
    level: 'N2',
    examples: [
      { japanese: '行くにしろ行かないにしろ、連絡してください。', romaji: 'Iku ni shiro ikanai ni shiro, renraku shite kudasai.', meaning: 'Baik pergi maupun tidak, tolong hubungi saya.' },
      { japanese: '高いにしろ安いにしろ、必要なものは買わなければならない。', romaji: 'Takai ni shiro yasui ni shiro, hitsuyou na mono wa kawanakereba naranai.', meaning: 'Baik mahal maupun murah, barang yang perlu harus dibeli.' },
      { japanese: '男にしろ女にしろ、優秀な人は採用したい。', romaji: 'Otoko ni shiro onna ni shiro, yuushuu na hito wa saiyou shitai.', meaning: 'Baik laki-laki maupun perempuan, saya ingin merekrut orang yang unggul.' }
    ]
  },
  { 
    title: '~に反して (Ni hanshite)', 
    formula: 'KB + に反して', 
    explanation: 'Berlawanan dengan... / Bertentangan dengan (harapan/prediksi).', 
    level: 'N2',
    examples: [
      { japanese: '予想に反して、試験は簡単だった。', romaji: 'Yosou ni hanshite, shiken wa kantan datta.', meaning: 'Berlawanan dengan prediksi, ujiannya mudah.' },
      { japanese: '親の期待に反して、彼は大学へ行かなかった。', romaji: 'Oya no kitai ni hanshite, kare wa daigaku e ikanakatta.', meaning: 'Bertentangan dengan harapan orang tua, dia tidak masuk universitas.' },
      { japanese: '意に反して、リーダーに選ばれてしまった。', romaji: 'I ni hanshite, riidaa ni erabarete shimatta.', meaning: 'Bertentangan dengan keinginan (saya), saya terpilih jadi pemimpin.' }
    ]
  },
  { 
    title: '~上は (Ue wa)', 
    formula: 'KK(Kamus/Ta) + 上は', 
    explanation: 'Karena sudah... maka (harus/akan/wajar). Menunjukkan tekad kuat setelah suatu kondisi terpenuhi. Mirip dengan "kara ni wa".', 
    level: 'N2',
    examples: [
      { japanese: '約束した上は、守らなければならない。', romaji: 'Yakusoku shita ue wa, mamoranakereba naranai.', meaning: 'Karena sudah berjanji, maka harus ditepati.' },
      { japanese: 'キャプテンに選ばれた上は、チームのために頑張りたい。', romaji: 'Kyaputen ni erabareta ue wa, chiimu no tame ni ganbaritai.', meaning: 'Karena sudah dipilih jadi kapten, saya ingin berusaha demi tim.' },
      { japanese: '日本に来た上は、日本語をマスターして帰りたい。', romaji: 'Nihon ni kita ue wa, Nihongo o masutaa shite kaeritai.', meaning: 'Karena sudah datang ke Jepang, saya ingin pulang setelah menguasai bahasa Jepang.' }
    ]
  },
  { 
    title: '~に沿って (Ni sotte)', 
    formula: 'KB + に沿って', 
    explanation: 'Sesuai dengan... / Mengikuti (garis/aturan/harapan).', 
    level: 'N2',
    examples: [
      { japanese: '川に沿って歩きます。', romaji: 'Kawa ni sotte arukimasu.', meaning: 'Berjalan mengikuti (sepanjang) sungai.' },
      { japanese: 'このマニュアルに沿って、作業を進めてください。', romaji: 'Kono manyuaru ni sotte, sagyou o susumete kudasai.', meaning: 'Tolong kerjakan sesuai dengan manual ini.' },
      { japanese: 'ご希望に沿えるよう、努力いたします。', romaji: 'Go-kibou ni soeru you, doryoku itashimasu.', meaning: 'Kami akan berusaha agar bisa sesuai dengan harapan Anda.' }
    ]
  }
];
