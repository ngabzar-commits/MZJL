import { Kanji } from "../../../types";

export const kanjin4_10: Kanji[] = [
  { char: '軽', level: 'N4', onyomi: ['KEI'], kunyomi: ['karu(i)'], meaning: 'Ringan', strokes: 12 },
  { char: '重', level: 'N4', onyomi: ['JUU'], kunyomi: ['omo(i)'], meaning: 'Berat', strokes: 9 },
  { char: '早', level: 'N4', onyomi: ['SOU'], kunyomi: ['haya(i)'], meaning: 'Cepat / Dini', strokes: 6 },
  { char: '遅', level: 'N4', onyomi: ['CHI'], kunyomi: ['oso(i)'], meaning: 'Lambat / Telat', strokes: 12 },
  { char: '近', level: 'N4', onyomi: ['KIN'], kunyomi: ['chika(i)'], meaning: 'Dekat', strokes: 7 },
  { char: '遠', level: 'N4', onyomi: ['EN'], kunyomi: ['too(i)'], meaning: 'Jauh', strokes: 13 },
  { char: '暑', level: 'N4', onyomi: ['SHO'], kunyomi: ['atsu(i)'], meaning: 'Panas (Cuaca)', strokes: 12 },
  { char: '寒', level: 'N4', onyomi: ['KAN'], kunyomi: ['samu(i)'], meaning: 'Dingin (Cuaca)', strokes: 12 },
  { char: '広', level: 'N4', onyomi: ['KOU'], kunyomi: ['hiro(i)'], meaning: 'Luas', strokes: 5 },
];