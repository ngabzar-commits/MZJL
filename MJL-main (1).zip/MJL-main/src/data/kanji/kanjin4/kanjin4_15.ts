import { Kanji } from "../../../types";

export const kanjin4_15: Kanji[] = [
  { char: '借', level: 'N4', onyomi: ['SHAKU'], kunyomi: ['ka(riru)'], meaning: 'Meminjam', strokes: 10 },
  { char: '返', level: 'N4', onyomi: ['HEN'], kunyomi: ['kae(su)'], meaning: 'Mengembalikan', strokes: 7 },
  { char: '送', level: 'N4', onyomi: ['SOU'], kunyomi: ['oku(ru)'], meaning: 'Mengirim', strokes: 9 },
  { char: '切', level: 'N4', onyomi: ['SETSU'], kunyomi: ['ki(ru)'], meaning: 'Memotong', strokes: 4 },
  { char: '洗', level: 'N4', onyomi: ['SEN'], kunyomi: ['ara(u)'], meaning: 'Mencuci', strokes: 9 },
  { char: '開', level: 'N4', onyomi: ['KAI'], kunyomi: ['a(keru)', 'hira(ku)'], meaning: 'Membuka', strokes: 12 },
  { char: '閉', level: 'N4', onyomi: ['HEI'], kunyomi: ['shi(meru)'], meaning: 'Menutup', strokes: 11 },
  { char: '着', level: 'N4', onyomi: ['CHAKU'], kunyomi: ['ki(ru)', 'tsu(ku)'], meaning: 'Memakai / Tiba', strokes: 12 },
  { char: '脱', level: 'N4', onyomi: ['DATSU'], kunyomi: ['nu(gu)'], meaning: 'Melepas', strokes: 11 },
];