import { Kanji } from "../../../types";

export const kanjin4_11: Kanji[] = [
  { char: '悪', level: 'N4', onyomi: ['AKU'], kunyomi: ['waru(i)'], meaning: 'Buruk', strokes: 11 },
  { char: '良', level: 'N4', onyomi: ['RYOU'], kunyomi: ['yo(i)'], meaning: 'Baik', strokes: 7 },
  { char: '低', level: 'N4', onyomi: ['TEI'], kunyomi: ['hiku(i)'], meaning: 'Rendah', strokes: 7 },
  { char: '暗', level: 'N4', onyomi: ['AN'], kunyomi: ['kura(i)'], meaning: 'Gelap', strokes: 13 },
  { char: '明', level: 'N4', onyomi: ['MEI'], kunyomi: ['aka(rui)'], meaning: 'Terang', strokes: 8 },
  { char: '太', level: 'N4', onyomi: ['TAI'], kunyomi: ['futo(i)'], meaning: 'Gemuk / Tebal', strokes: 4 },
  { char: '細', level: 'N4', onyomi: ['SAI'], kunyomi: ['hoso(i)'], meaning: 'Tipis / Halus', strokes: 11 },
  { char: '短', level: 'N4', onyomi: ['TAN'], kunyomi: ['mijika(i)'], meaning: 'Pendek', strokes: 12 },
  { char: '便', level: 'N4', onyomi: ['BEN'], kunyomi: ['tayo(ri)'], meaning: 'Praktis / Surat', strokes: 9 },
];