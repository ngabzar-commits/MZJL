import { Kanji } from "../../../types";

export const kanjin4_14: Kanji[] = [
  { char: '京', level: 'N4', onyomi: ['KYOU'], kunyomi: ['miyako'], meaning: 'Ibukota', strokes: 8 },
  { char: '都', level: 'N4', onyomi: ['TO'], kunyomi: ['miyako'], meaning: 'Metropolis', strokes: 11 },
  { char: '県', level: 'N4', onyomi: ['KEN'], kunyomi: ['-'], meaning: 'Prefektur', strokes: 9 },
  { char: '市', level: 'N4', onyomi: ['SHI'], kunyomi: ['ichi'], meaning: 'Kota / Pasar', strokes: 5 },
  { char: '区', level: 'N4', onyomi: ['KU'], kunyomi: ['-'], meaning: 'Distrik', strokes: 4 },
  { char: '町', level: 'N4', onyomi: ['CHOU'], kunyomi: ['machi'], meaning: 'Kota Kecil', strokes: 7 },
  { char: '村', level: 'N4', onyomi: ['SON'], kunyomi: ['mura'], meaning: 'Desa', strokes: 7 },
  { char: '界', level: 'N4', onyomi: ['KAI'], kunyomi: ['-'], meaning: 'Dunia', strokes: 9 },
  { char: '世', level: 'N4', onyomi: ['SEI', 'SE'], kunyomi: ['yo'], meaning: 'Dunia / Generasi', strokes: 5 },
];