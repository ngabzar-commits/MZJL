import { Kanji } from "../../../types";

export const kanjin4_3: Kanji[] = [
  { 
    char: '飯', level: 'N4', onyomi: ['HAN'], kunyomi: ['meshi'], meaning: 'Nasi / Makanan', strokes: 12,
    story: 'Makanan (食) yang dimakan saat kembali (反). NASI.',
    examples: [
      { word: 'ご飯', reading: 'Gohan', meaning: 'Nasi/Makan' },
      { word: '朝ご飯', reading: 'Asagohan', meaning: 'Sarapan' },
      { word: '昼ご飯', reading: 'Hirugohan', meaning: 'Makan siang' }
    ]
  },
  { 
    char: '肉', level: 'N4', onyomi: ['NIKU'], kunyomi: ['-'], meaning: 'Daging', strokes: 6,
    story: 'Gambar potongan DAGING dengan serat-seratnya.',
    examples: [
      { word: '肉', reading: 'Niku', meaning: 'Daging' },
      { word: '牛肉', reading: 'Gyuuniku', meaning: 'Daging sapi' },
      { word: '鳥肉', reading: 'Toriniku', meaning: 'Daging ayam' }
    ]
  },
  { 
    char: '魚', level: 'N4', onyomi: ['GYO'], kunyomi: ['sakana'], meaning: 'Ikan', strokes: 11,
    story: 'Gambar IKAN dengan kepala, badan bersisik, dan ekor (api).',
    examples: [
      { word: '魚', reading: 'Sakana', meaning: 'Ikan' },
      { word: '金魚', reading: 'Kingyo', meaning: 'Ikan mas' }
    ]
  },
  { 
    char: '野', level: 'N4', onyomi: ['YA'], kunyomi: ['no'], meaning: 'Ladang / Liar', strokes: 11,
    story: 'Desa (里) yang diberi (予) lahan terbuka. LADANG.',
    examples: [
      { word: '野菜', reading: 'Yasai', meaning: 'Sayuran' },
      { word: '野原', reading: 'Nohara', meaning: 'Padang rumput' },
      { word: '野球', reading: 'Yakyuu', meaning: 'Bisbol' }
    ]
  },
  { 
    char: '菜', level: 'N4', onyomi: ['SAI'], kunyomi: ['na'], meaning: 'Sayur', strokes: 11,
    story: 'Rumput (艹) yang dipetik (采) dengan tangan. SAYURAN.',
    examples: [
      { word: '野菜', reading: 'Yasai', meaning: 'Sayuran' }
    ]
  },
  { 
    char: '茶', level: 'N4', onyomi: ['CHA', 'SA'], kunyomi: ['-'], meaning: 'Teh', strokes: 9,
    story: 'Rumput (艹) untuk manusia (人) yang berasal dari pohon (木). TEH.',
    examples: [
      { word: 'お茶', reading: 'Ocha', meaning: 'Teh' },
      { word: '茶色', reading: 'Chairo', meaning: 'Warna coklat' },
      { word: '紅茶', reading: 'Koucha', meaning: 'Teh hitam' }
    ]
  },
  { 
    char: '酒', level: 'N4', onyomi: ['SHU'], kunyomi: ['sake'], meaning: 'Alkohol', strokes: 10,
    story: 'Air (氵) di dalam guci fermentasi (酉). ARAK/ALKOHOL.',
    examples: [
      { word: 'お酒', reading: 'Osake', meaning: 'Alkohol' },
      { word: '日本酒', reading: 'Nihonshu', meaning: 'Sake Jepang' },
      { word: '居酒屋', reading: 'Izakaya', meaning: 'Kedai minum' }
    ]
  },
  { 
    char: '牛', level: 'N4', onyomi: ['GYUU'], kunyomi: ['ushi'], meaning: 'Sapi', strokes: 4,
    story: 'Kepala SAPI dengan sepasang tanduk.',
    examples: [
      { word: '牛', reading: 'Ushi', meaning: 'Sapi' },
      { word: '牛乳', reading: 'Gyuunyuu', meaning: 'Susu sapi' },
      { word: '牛肉', reading: 'Gyuuniku', meaning: 'Daging sapi' }
    ]
  },
  { 
    char: '鳥', level: 'N4', onyomi: ['CHOU'], kunyomi: ['tori'], meaning: 'Burung', strokes: 11,
    story: 'Gambar BURUNG dengan mata, bulu, dan empat titik kaki.',
    examples: [
      { word: '鳥', reading: 'Tori', meaning: 'Burung' },
      { word: '小鳥', reading: 'Kotori', meaning: 'Burung kecil' },
      { word: '焼き鳥', reading: 'Yakitori', meaning: 'Sate ayam' }
    ]
  },
];