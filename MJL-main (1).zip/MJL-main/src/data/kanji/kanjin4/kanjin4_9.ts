import { Kanji } from "../../../types";

export const kanjin4_9: Kanji[] = [
  { char: '音', level: 'N4', onyomi: ['ON'], kunyomi: ['oto'], meaning: 'Suara', strokes: 9 },
  { char: '楽', level: 'N4', onyomi: ['GAKU', 'RAKU'], kunyomi: ['tano(shii)'], meaning: 'Musik / Menyenangkan', strokes: 13 },
  { char: '歌', level: 'N4', onyomi: ['KA'], kunyomi: ['uta'], meaning: 'Lagu', strokes: 14 },
  { char: '画', level: 'N4', onyomi: ['GA', 'KAKU'], kunyomi: ['-'], meaning: 'Gambar / Goresan', strokes: 8 },
  { char: '写', level: 'N4', onyomi: ['SHA'], kunyomi: ['utsu(su)'], meaning: 'Menyalin / Foto', strokes: 5 },
  { char: '真', level: 'N4', onyomi: ['SHIN'], kunyomi: ['ma'], meaning: 'Kebenaran', strokes: 10 },
  { char: '色', level: 'N4', onyomi: ['SHOKU'], kunyomi: ['iro'], meaning: 'Warna', strokes: 6 },
  { char: '味', level: 'N4', onyomi: ['MI'], kunyomi: ['aji'], meaning: 'Rasa', strokes: 8 },
  { char: '料', level: 'N4', onyomi: ['RYOU'], kunyomi: ['-'], meaning: 'Bahan / Biaya', strokes: 10 },
];