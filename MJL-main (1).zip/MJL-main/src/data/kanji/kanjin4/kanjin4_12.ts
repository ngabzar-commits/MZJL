import { Kanji } from "../../../types";

export const kanjin4_12: Kanji[] = [
  { char: '利', level: 'N4', onyomi: ['RI'], kunyomi: ['ki(ku)'], meaning: 'Keuntungan', strokes: 7 },
  { char: '不', level: 'N4', onyomi: ['FU'], kunyomi: ['-'], meaning: 'Tidak', strokes: 4 },
  { char: '紙', level: 'N4', onyomi: ['SHI'], kunyomi: ['kami'], meaning: 'Kertas', strokes: 10 },
  { char: '手', level: 'N4', onyomi: ['SHU'], kunyomi: ['te'], meaning: 'Tangan', strokes: 4 },
  { char: '工', level: 'N4', onyomi: ['KOU', 'KU'], kunyomi: ['-'], meaning: 'Konstruksi', strokes: 3 },
  { char: '場', level: 'N4', onyomi: ['JOU'], kunyomi: ['ba'], meaning: 'Tempat', strokes: 12 },
  { char: '所', level: 'N4', onyomi: ['SHO'], kunyomi: ['tokoro'], meaning: 'Tempat', strokes: 8 },
  { char: '有', level: 'N4', onyomi: ['YUU'], kunyomi: ['a(ru)'], meaning: 'Ada / Memiliki', strokes: 6 },
  { char: '無', level: 'N4', onyomi: ['MU'], kunyomi: ['na(i)'], meaning: 'Tidak Ada', strokes: 12 },
];