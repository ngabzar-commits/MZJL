import { Kanji } from "../../../types";

export const kanjin4_4: Kanji[] = [
  { 
    char: '店', level: 'N4', onyomi: ['TEN'], kunyomi: ['mise'], meaning: 'Toko', strokes: 8,
    story: 'Bangunan (广) tempat meramal/menjual (占). TOKO.',
    examples: [
      { word: '店', reading: 'Mise', meaning: 'Toko' },
      { word: '店員', reading: 'Tenin', meaning: 'Pelayan toko' },
      { word: '売店', reading: 'Baiten', meaning: 'Kios' }
    ]
  },
  { 
    char: '屋', level: 'N4', onyomi: ['OKU'], kunyomi: ['ya'], meaning: 'Atap / Toko', strokes: 9,
    story: 'Orang (mayat/palsu - 尸) sampai (至) di bawah ATAP untuk berteduh.',
    examples: [
      { word: '部屋', reading: 'Heya', meaning: 'Kamar' },
      { word: '屋上', reading: 'Okujou', meaning: 'Atap gedung' },
      { word: '八百屋', reading: 'Yaoya', meaning: 'Toko sayur' }
    ]
  },
  { 
    char: '堂', level: 'N4', onyomi: ['DOU'], kunyomi: ['-'], meaning: 'Aula', strokes: 11,
    story: 'Tanah (土) yang ditinggikan dan mulia (尚). AULA besar.',
    examples: [
      { word: '食堂', reading: 'Shokudou', meaning: 'Kantin' },
      { word: '講堂', reading: 'Koudou', meaning: 'Auditorium' }
    ]
  },
  { 
    char: '室', level: 'N4', onyomi: ['SHITSU'], kunyomi: ['muro'], meaning: 'Ruangan', strokes: 9,
    story: 'Di bawah atap (宀) sampai (至) ke tujuan. RUANGAN.',
    examples: [
      { word: '教室', reading: 'Kyoushitsu', meaning: 'Kelas' },
      { word: '会議室', reading: 'Kaigishitsu', meaning: 'Ruang rapat' }
    ]
  },
  { 
    char: '館', level: 'N4', onyomi: ['KAN'], kunyomi: ['yakata'], meaning: 'Gedung', strokes: 16,
    story: 'Tempat makan (食) di bangunan resmi (官). GEDUNG.',
    examples: [
      { word: '図書館', reading: 'Toshokan', meaning: 'Perpustakaan' },
      { word: '映画館', reading: 'Eigakan', meaning: 'Bioskop' },
      { word: '大使館', reading: 'Taishikan', meaning: 'Kedutaan' }
    ]
  },
  { 
    char: '図', level: 'N4', onyomi: ['ZU', 'TO'], kunyomi: ['haka(ru)'], meaning: 'Gambar / Peta', strokes: 7,
    story: 'Peta berbentuk X di dalam kotak (囗). GAMBAR/RENCANA.',
    examples: [
      { word: '地図', reading: 'Chizu', meaning: 'Peta' },
      { word: '図書館', reading: 'Toshokan', meaning: 'Perpustakaan' }
    ]
  },
  { 
    char: '病', level: 'N4', onyomi: ['BYOU'], kunyomi: ['yamai'], meaning: 'Sakit', strokes: 10,
    story: 'Penyakit (疒) level ketiga (丙) yang parah. SAKIT.',
    examples: [
      { word: '病院', reading: 'Byouin', meaning: 'Rumah sakit' },
      { word: '病気', reading: 'Byouki', meaning: 'Sakit' }
    ]
  },
  { 
    char: '院', level: 'N4', onyomi: ['IN'], kunyomi: ['-'], meaning: 'Institusi', strokes: 10,
    story: 'Bangunan (阝) yang sempurna (完). INSTITUSI.',
    examples: [
      { word: '病院', reading: 'Byouin', meaning: 'Rumah sakit' },
      { word: '大学院', reading: 'Daigakuin', meaning: 'Pascasarjana' }
    ]
  },
  { 
    char: '建', level: 'N4', onyomi: ['KEN'], kunyomi: ['ta(teru)'], meaning: 'Membangun', strokes: 9,
    story: 'Memegang kuas (聿) sambil merencanakan jalan (廴). MEMBANGUN.',
    examples: [
      { word: '建てる', reading: 'Tateru', meaning: 'Membangun' },
      { word: '建物', reading: 'Tatemono', meaning: 'Bangunan' }
    ]
  },
];