import { Kanji } from "../../../types";

export const kanjin4_18: Kanji[] = [
  { char: '集', level: 'N4', onyomi: ['SHUU'], kunyomi: ['atsu(maru)'], meaning: 'Berkumpul', strokes: 12 },
  { char: '転', level: 'N4', onyomi: ['TEN'], kunyomi: ['koro(bu)'], meaning: 'Berputar / Jatuh', strokes: 11 },
  { char: '進', level: 'N4', onyomi: ['SHIN'], kunyomi: ['susu(mu)'], meaning: 'Maju', strokes: 11 },
  { char: '通', level: 'N4', onyomi: ['TSUU'], kunyomi: ['too(ru)'], meaning: 'Melewati / Komute', strokes: 10 },
  { char: '連', level: 'N4', onyomi: ['REN'], kunyomi: ['tsu(reru)'], meaning: 'Membawa / Hubungan', strokes: 10 },
  { char: '計', level: 'N4', onyomi: ['KEI'], kunyomi: ['haka(ru)'], meaning: 'Rencana / Ukur', strokes: 9 },
  { char: '以', level: 'N4', onyomi: ['I'], kunyomi: ['mot(te)'], meaning: 'Oleh / Daripada', strokes: 5 },
  { char: '度', level: 'N4', onyomi: ['DO'], kunyomi: ['tabi'], meaning: 'Derajat / Kali', strokes: 9 },
  { char: '民', level: 'N4', onyomi: ['MIN'], kunyomi: ['tami'], meaning: 'Rakyat', strokes: 5 },
];