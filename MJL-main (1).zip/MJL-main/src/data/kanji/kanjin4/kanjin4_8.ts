import { Kanji } from "../../../types";

export const kanjin4_8: Kanji[] = [
  { char: '思', level: 'N4', onyomi: ['SHI'], kunyomi: ['omo(u)'], meaning: 'Berpikir', strokes: 9 },
  { char: '考', level: 'N4', onyomi: ['KOU'], kunyomi: ['kanga(eru)'], meaning: 'Memikirkan', strokes: 6 },
  { char: '知', level: 'N4', onyomi: ['CHI'], kunyomi: ['shi(ru)'], meaning: 'Tahu', strokes: 8 },
  { char: '待', level: 'N4', onyomi: ['TAI'], kunyomi: ['ma(tsu)'], meaning: 'Menunggu', strokes: 9 },
  { char: '急', level: 'N4', onyomi: ['KYUU'], kunyomi: ['iso(gu)'], meaning: 'Buru-buru', strokes: 9 },
  { char: '使', level: 'N4', onyomi: ['SHI'], kunyomi: ['tsuka(u)'], meaning: 'Menggunakan', strokes: 8 },
  { char: '作', level: 'N4', onyomi: ['SAKU', 'SA'], kunyomi: ['tsuku(ru)'], meaning: 'Membuat', strokes: 7 },
  { char: '売', level: 'N4', onyomi: ['BAI'], kunyomi: ['u(ru)'], meaning: 'Menjual', strokes: 7 },
  { char: '貸', level: 'N4', onyomi: ['TAI'], kunyomi: ['ka(su)'], meaning: 'Meminjamkan', strokes: 12 },
];