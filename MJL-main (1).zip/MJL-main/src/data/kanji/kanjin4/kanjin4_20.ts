import { Kanji } from "../../../types";

export const kanjin4_20: Kanji[] = [
  { char: '持', level: 'N4', onyomi: ['JI'], kunyomi: ['mo(tsu)'], meaning: 'Memegang', strokes: 9 },
  { char: '歌', level: 'N4', onyomi: ['KA'], kunyomi: ['uta'], meaning: 'Menyanyi', strokes: 14 },
  { char: '真', level: 'N4', onyomi: ['SHIN'], kunyomi: ['ma'], meaning: 'Kebenaran', strokes: 10 },
  { char: '急', level: 'N4', onyomi: ['KYUU'], kunyomi: ['iso(gu)'], meaning: 'Buru-buru', strokes: 9 },
  { char: '建', level: 'N4', onyomi: ['KEN'], kunyomi: ['ta(teru)'], meaning: 'Bangunan', strokes: 9 },
  { char: '引', level: 'N4', onyomi: ['IN'], kunyomi: ['hi(ku)'], meaning: 'Menarik', strokes: 4 },
  { char: '公', level: 'N4', onyomi: ['KOU'], kunyomi: ['oyake'], meaning: 'Publik', strokes: 4 },
  { char: '園', level: 'N4', onyomi: ['EN'], kunyomi: ['sono'], meaning: 'Taman', strokes: 13 },
  { char: '住', level: 'N4', onyomi: ['JUU'], kunyomi: ['su(mu)'], meaning: 'Tinggal', strokes: 7 },
];