import { Kanji } from "../../../types";

export const kanjin5_3: Kanji[] = [
  { 
    char: '百', level: 'N5', onyomi: ['HYAKU'], kunyomi: ['-'], meaning: 'Ratus', strokes: 6,
    story: 'Satu (一) buah koin putih (白).',
    examples: [
        { word: '百', reading: 'Hyaku', meaning: '100' },
        { word: '三百', reading: 'Sanbyaku', meaning: '300' },
        { word: '六百', reading: 'Roppyaku', meaning: '600' }
    ]
  },
  { 
    char: '千', level: 'N5', onyomi: ['SEN'], kunyomi: ['chi'], meaning: 'Ribu', strokes: 3,
    story: 'Orang (人) dengan tanda silang (十) di matanya karena melihat uang seribu.',
    examples: [
        { word: '千', reading: 'Sen', meaning: '1000' },
        { word: '三千', reading: 'Sanzen', meaning: '3000' },
        { word: '千葉', reading: 'Chiba', meaning: 'Prefektur Chiba' }
    ]
  },
  { 
    char: '万', level: 'N5', onyomi: ['MAN', 'BAN'], kunyomi: ['-'], meaning: 'Puluh Ribu', strokes: 3,
    story: 'Angka lima (五) yang kehilangan topinya.',
    examples: [
        { word: '一万', reading: 'Ichiman', meaning: '10.000' },
        { word: '万国', reading: 'Bankoku', meaning: 'Semua negara' },
        { word: '万年筆', reading: 'Mannenhitsu', meaning: 'Pena' }
    ]
  },
  { 
    char: '円', level: 'N5', onyomi: ['EN'], kunyomi: ['maru(i)'], meaning: 'Yen / Lingkaran', strokes: 4,
    story: 'Bentuk koin yang bulat tertutup.',
    examples: [
        { word: '百円', reading: 'Hyakuen', meaning: '100 Yen' },
        { word: '円高', reading: 'Endaka', meaning: 'Apresiasi Yen' },
        { word: '円い', reading: 'Marui', meaning: 'Bulat' }
    ]
  },
  { 
    char: '年', level: 'N5', onyomi: ['NEN'], kunyomi: ['toshi'], meaning: 'Tahun', strokes: 6,
    story: 'Kuda (午) membawa padi hasil panen setahun sekali.',
    examples: [
        { word: '来年', reading: 'Rainen', meaning: 'Tahun depan' },
        { word: '今年', reading: 'Kotoshi', meaning: 'Tahun ini' },
        { word: '去年', reading: 'Kyonen', meaning: 'Tahun lalu' }
    ]
  },
];