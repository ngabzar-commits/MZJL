import { Kanji } from "../../../types";

export const kanjin5_11: Kanji[] = [
  { 
    char: '買', level: 'N5', onyomi: ['BAI'], kunyomi: ['ka(u)'], meaning: 'Membeli', strokes: 12,
    story: 'Mata (目) melihat kerang/uang (貝) untuk MEMBELI sesuatu.',
    examples: [
      { word: '買う', reading: 'Kau', meaning: 'Membeli' },
      { word: '買い物', reading: 'Kaimono', meaning: 'Belanja' },
      { word: '売買', reading: 'Baibai', meaning: 'Jual beli' }
    ]
  },
  { 
    char: '出', level: 'N5', onyomi: ['SHUTSU'], kunyomi: ['de(ru)', 'da(su)'], meaning: 'Keluar', strokes: 5,
    story: 'Tanaman yang tumbuh KELUAR dari tanah. Atau dua gunung bertumpuk.',
    examples: [
      { word: '出る', reading: 'Deru', meaning: 'Keluar' },
      { word: '出す', reading: 'Dasu', meaning: 'Mengeluarkan' },
      { word: '出口', reading: 'Deguchi', meaning: 'Pintu keluar' },
      { word: '外出', reading: 'Gaishutsu', meaning: 'Pergi keluar' }
    ]
  },
  { 
    char: '入', level: 'N5', onyomi: ['NYUU'], kunyomi: ['hai(ru)', 'i(reru)'], meaning: 'Masuk', strokes: 2,
    story: 'Seseorang melangkah MASUK. Kebalikan dari orang (人).',
    examples: [
      { word: '入る', reading: 'Hairu', meaning: 'Masuk' },
      { word: '入れる', reading: 'Ireru', meaning: 'Memasukkan' },
      { word: '入口', reading: 'Iriguchi', meaning: 'Pintu masuk' },
      { word: '入学', reading: 'Nyuugaku', meaning: 'Masuk sekolah' }
    ]
  },
  { 
    char: '会', level: 'N5', onyomi: ['KAI'], kunyomi: ['a(u)'], meaning: 'Bertemu', strokes: 6,
    story: 'Orang-orang (人) BERTEMU di bawah atap/awan (云).',
    examples: [
      { word: '会う', reading: 'Au', meaning: 'Bertemu' },
      { word: '会話', reading: 'Kaiwa', meaning: 'Percakapan' },
      { word: '会社', reading: 'Kaisha', meaning: 'Perusahaan' },
      { word: '大会', reading: 'Taikai', meaning: 'Turnamen' }
    ]
  },
  { 
    char: '言', level: 'N5', onyomi: ['GEN', 'GON'], kunyomi: ['i(u)'], meaning: 'Berkata', strokes: 7,
    story: 'Kata-kata (garis-garis) yang keluar dari mulut (口).',
    examples: [
      { word: '言う', reading: 'Iu', meaning: 'Berkata' },
      { word: '言葉', reading: 'Kotoba', meaning: 'Kata-kata/Bahasa' },
      { word: '言語', reading: 'Gengo', meaning: 'Bahasa' }
    ]
  },
];