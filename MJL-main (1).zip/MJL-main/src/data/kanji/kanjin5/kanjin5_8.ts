import { Kanji } from "../../../types";

export const kanjin5_8: Kanji[] = [
  { 
    char: '手', level: 'N5', onyomi: ['SHU'], kunyomi: ['te'], meaning: 'Tangan', strokes: 4,
    story: 'Garis-garis yang menyerupai jari-jari tangan.',
    examples: [
        { word: '手', reading: 'Te', meaning: 'Tangan' },
        { word: '手紙', reading: 'Tegami', meaning: 'Surat' },
        { word: '切手', reading: 'Kitte', meaning: 'Prangko' }
    ]
  },
  { 
    char: '足', level: 'N5', onyomi: ['SOKU'], kunyomi: ['ashi'], meaning: 'Kaki', strokes: 7,
    story: 'Mulut (口) di atas tubuh yang sedang berjalan.',
    examples: [
        { word: '足', reading: 'Ashi', meaning: 'Kaki' },
        { word: '足りる', reading: 'Tariru', meaning: 'Cukup' },
        { word: '一足', reading: 'Issoku', meaning: 'Sepasang (sepatu)' }
    ]
  },
  { 
    char: '力', level: 'N5', onyomi: ['RYOKU', 'RIKI'], kunyomi: ['chikara'], meaning: 'Kekuatan', strokes: 2,
    story: 'Otot lengan yang menonjol saat ditekuk.',
    examples: [
        { word: '力', reading: 'Chikara', meaning: 'Kekuatan' },
        { word: '協力', reading: 'Kyouryoku', meaning: 'Kerjasama' },
        { word: '実力', reading: 'Jitsuryoku', meaning: 'Kemampuan nyata' }
    ]
  },
  { 
    char: '休', level: 'N5', onyomi: ['KYUU'], kunyomi: ['yasu(mu)'], meaning: 'Istirahat', strokes: 6,
    story: 'Orang (人) bersandar di pohon (木) untuk beristirahat.',
    examples: [
        { word: '休む', reading: 'Yasumu', meaning: 'Istirahat' },
        { word: '休み', reading: 'Yasumi', meaning: 'Libur' },
        { word: '休日', reading: 'Kyuujitsu', meaning: 'Hari libur' }
    ]
  },
  { 
    char: '立', level: 'N5', onyomi: ['RITSU'], kunyomi: ['ta(tsu)'], meaning: 'Berdiri', strokes: 5,
    story: 'Seseorang yang berdiri tegak di atas tanah.',
    examples: [
        { word: '立つ', reading: 'Tatsu', meaning: 'Berdiri' },
        { word: '国立', reading: 'Kokuritsu', meaning: 'Nasional (Berdiri oleh negara)' }
    ]
  },
];