import { Kanji } from "../../../types";

export const kanjin5_7: Kanji[] = [
  { 
    char: '父', level: 'N5', onyomi: ['FU'], kunyomi: ['chichi'], meaning: 'Ayah', strokes: 4,
    story: 'Ayah yang memiliki kumis.',
    examples: [
        { word: '父', reading: 'Chichi', meaning: 'Ayah (saya)' },
        { word: 'お父さん', reading: 'Otousan', meaning: 'Ayah (orang lain)' },
        { word: '祖父', reading: 'Sofu', meaning: 'Kakek' }
    ]
  },
  { 
    char: '母', level: 'N5', onyomi: ['BO'], kunyomi: ['haha'], meaning: 'Ibu', strokes: 5,
    story: 'Ibu yang sedang menyusui (ada dua titik di dada).',
    examples: [
        { word: '母', reading: 'Haha', meaning: 'Ibu (saya)' },
        { word: 'お母さん', reading: 'Okaasan', meaning: 'Ibu (orang lain)' },
        { word: '母国', reading: 'Bokoku', meaning: 'Tanah air' }
    ]
  },
  { 
    char: '目', level: 'N5', onyomi: ['MOKU'], kunyomi: ['me'], meaning: 'Mata', strokes: 5,
    story: 'Kotak dengan garis-garis di dalamnya menyerupai pupil mata.',
    examples: [
        { word: '目', reading: 'Me', meaning: 'Mata' },
        { word: '目的', reading: 'Mokuteki', meaning: 'Tujuan' },
        { word: '目薬', reading: 'Megusuri', meaning: 'Obat mata' }
    ]
  },
  { 
    char: '耳', level: 'N5', onyomi: ['JI'], kunyomi: ['mimi'], meaning: 'Telinga', strokes: 6,
    story: 'Bentuk kotak berlapis yang menyerupai daun telinga.',
    examples: [
        { word: '耳', reading: 'Mimi', meaning: 'Telinga' },
        { word: '耳鼻科', reading: 'Jibika', meaning: 'THT (Telinga Hidung Tenggorokan)' }
    ]
  },
  { 
    char: '口', level: 'N5', onyomi: ['KOU'], kunyomi: ['kuchi'], meaning: 'Mulut', strokes: 3,
    story: 'Kotak terbuka seperti mulut yang menganga.',
    examples: [
        { word: '口', reading: 'Kuchi', meaning: 'Mulut' },
        { word: '出口', reading: 'Deguchi', meaning: 'Pintu keluar' },
        { word: '入口', reading: 'Iriguchi', meaning: 'Pintu masuk' }
    ]
  },
];