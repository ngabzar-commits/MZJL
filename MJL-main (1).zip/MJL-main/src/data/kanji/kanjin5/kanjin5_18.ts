import { Kanji } from "../../../types";

export const kanjin5_18: Kanji[] = [
  { 
    char: '古', level: 'N5', onyomi: ['KO'], kunyomi: ['furu(i)'], meaning: 'Lama / Tua', strokes: 5,
    story: 'Cerita dari sepuluh (十) mulut (口) generasi yang sudah LAMA.',
    examples: [
      { word: '古い', reading: 'Furui', meaning: 'Lama/Tua (Benda)' },
      { word: '中古', reading: 'Chuuko', meaning: 'Barang bekas' }
    ]
  },
  { 
    char: '長', level: 'N5', onyomi: ['CHOU'], kunyomi: ['naga(i)'], meaning: 'Panjang / Ketua', strokes: 8,
    story: 'Rambut yang tumbuh sangat PANJANG.',
    examples: [
      { word: '長い', reading: 'Nagai', meaning: 'Panjang' },
      { word: '社長', reading: 'Shachou', meaning: 'Presiden direktur' },
      { word: '校長', reading: 'Kouchou', meaning: 'Kepala sekolah' }
    ]
  },
  { 
    char: '多', level: 'N5', onyomi: ['TA'], kunyomi: ['oo(i)'], meaning: 'Banyak', strokes: 6,
    story: 'Dua potong daging (夕) bertumpuk. BANYAK.',
    examples: [
      { word: '多い', reading: 'Ooi', meaning: 'Banyak' },
      { word: '多分', reading: 'Tabun', meaning: 'Mungkin' }
    ]
  },
  { 
    char: '少', level: 'N5', onyomi: ['SHOU'], kunyomi: ['suku(nai)', 'suoko(shi)'], meaning: 'Sedikit', strokes: 4,
    story: 'Kecil (小) dengan satu goresan lagi. SEDIKIT.',
    examples: [
      { word: '少ない', reading: 'Sukunai', meaning: 'Sedikit (jumlah)' },
      { word: '少し', reading: 'Sukoshi', meaning: 'Sedikit (kuantitas)' },
      { word: '少年', reading: 'Shounen', meaning: 'Anak laki-laki' }
    ]
  },
  { 
    char: '半', level: 'N5', onyomi: ['HAN'], kunyomi: ['naka(ba)'], meaning: 'Setengah', strokes: 5,
    story: 'Garis vertikal membagi dua bagian menjadi SETENGAH.',
    examples: [
      { word: '半分', reading: 'Hanbun', meaning: 'Setengah' },
      { word: '半年', reading: 'Hantoshi', meaning: 'Setengah tahun' },
      { word: '三時半', reading: 'Sanji han', meaning: 'Jam 3:30' }
    ]
  },
];