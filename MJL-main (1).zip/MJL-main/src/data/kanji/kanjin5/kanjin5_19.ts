import { Kanji } from "../../../types";

export const kanjin5_19: Kanji[] = [
  { 
    char: '白', level: 'N5', onyomi: ['HAKU'], kunyomi: ['shiro'], meaning: 'Putih', strokes: 5,
    story: 'Sinar matahari (日) yang PUTIH terang dengan satu sinar di atas.',
    examples: [
      { word: '白い', reading: 'Shiroi', meaning: 'Putih' },
      { word: '面白い', reading: 'Omoshiroi', meaning: 'Menarik' }
    ]
  },
  { 
    char: '黒', level: 'N5', onyomi: ['KOKU'], kunyomi: ['kuro'], meaning: 'Hitam', strokes: 11,
    story: 'Tanah ladang (田) yang dibakar api (灬) menjadi abu HITAM.',
    examples: [
      { word: '黒い', reading: 'Kuroi', meaning: 'Hitam' },
      { word: '黒板', reading: 'Kokuban', meaning: 'Papan tulis hitam' }
    ]
  },
  { 
    char: '赤', level: 'N5', onyomi: ['SEKI'], kunyomi: ['aka'], meaning: 'Merah', strokes: 7,
    story: 'Api (火) besar (大) yang menyala berwarna MERAH.',
    examples: [
      { word: '赤い', reading: 'Akai', meaning: 'Merah' },
      { word: '赤ちゃん', reading: 'Akachan', meaning: 'Bayi' }
    ]
  },
  { 
    char: '青', level: 'N5', onyomi: ['SEI'], kunyomi: ['ao'], meaning: 'Biru', strokes: 8,
    story: 'Warna tanaman muda (生) di bawah sinar bulan. BIRU/HIJAU.',
    examples: [
      { word: '青い', reading: 'Aoi', meaning: 'Biru' },
      { word: '青信号', reading: 'Aoshingou', meaning: 'Lampu hijau' },
      { word: '青年', reading: 'Seinen', meaning: 'Pemuda' }
    ]
  },
  { 
    char: '本', level: 'N5', onyomi: ['HON'], kunyomi: ['moto'], meaning: 'Buku / Asal', strokes: 5,
    story: 'Pohon (木) dengan tanda garis di akarnya (ASAL MULA). Kertas buku dari pohon.',
    examples: [
      { word: '本', reading: 'Hon', meaning: 'Buku' },
      { word: '日本', reading: 'Nihon', meaning: 'Jepang (Negara asal matahari)' },
      { word: '山本', reading: 'Yamamoto', meaning: 'Yamamoto (Nama)' }
    ]
  },
];