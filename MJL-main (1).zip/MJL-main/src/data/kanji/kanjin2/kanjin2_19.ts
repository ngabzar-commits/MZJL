
import { Kanji } from "../../../types";

export const kanjin2_19: Kanji[] = [
  // Akan diisi lebih lanjut
];
