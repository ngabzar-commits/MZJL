
import { Kanji } from "../../../types";

export const kanjin2_11: Kanji[] = [
  // Akan diisi lebih lanjut
];
