
import { Kanji } from "../../../types";

export const kanjin2_10: Kanji[] = [
  // Akan diisi lebih lanjut
];
