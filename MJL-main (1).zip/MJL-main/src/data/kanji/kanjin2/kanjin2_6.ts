
import { Kanji } from "../../../types";

export const kanjin2_6: Kanji[] = [
  // Akan diisi lebih lanjut
];
