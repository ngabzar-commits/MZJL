
import { Kanji } from "../../../types";

export const kanjin2_8: Kanji[] = [
  // Akan diisi lebih lanjut
];
