
import { Kanji } from "../../../types";

export const kanjin2_7: Kanji[] = [
  // Akan diisi lebih lanjut
];
