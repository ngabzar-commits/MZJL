
import { Kanji } from "../../../types";

export const kanjin2_18: Kanji[] = [
  // Akan diisi lebih lanjut
];
