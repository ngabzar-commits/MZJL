
import { Kanji } from "../../../types";

export const kanjin2_16: Kanji[] = [
  // Akan diisi lebih lanjut
];
