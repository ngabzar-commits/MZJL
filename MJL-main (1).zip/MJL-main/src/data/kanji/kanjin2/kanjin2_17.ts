
import { Kanji } from "../../../types";

export const kanjin2_17: Kanji[] = [
  // Akan diisi lebih lanjut
];
