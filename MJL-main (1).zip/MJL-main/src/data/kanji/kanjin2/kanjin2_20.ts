
import { Kanji } from "../../../types";

export const kanjin2_20: Kanji[] = [
  // Akan diisi lebih lanjut
];
