
import { Kanji } from "../../../types";

export const kanjin2_9: Kanji[] = [
  // Akan diisi lebih lanjut
];
