
import { Kanji } from "../../../types";

export const kanjin2_14: Kanji[] = [
  // Akan diisi lebih lanjut
];
