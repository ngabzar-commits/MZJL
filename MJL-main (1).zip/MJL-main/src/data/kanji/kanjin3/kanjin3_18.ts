
import { Kanji } from "../../../types";

export const kanjin3_18: Kanji[] = [
  // Akan diisi lebih lanjut
];
