
import { Kanji } from "../../../types";

export const kanjin3_13: Kanji[] = [
  // Akan diisi lebih lanjut
];
