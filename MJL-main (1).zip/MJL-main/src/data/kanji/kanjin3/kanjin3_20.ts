
import { Kanji } from "../../../types";

export const kanjin3_20: Kanji[] = [
  // Akan diisi lebih lanjut
];
