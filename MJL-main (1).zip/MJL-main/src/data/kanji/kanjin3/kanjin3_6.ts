
import { Kanji } from "../../../types";

export const kanjin3_6: Kanji[] = [
  // Akan diisi lebih lanjut
];
