
import { Kanji } from "../../../types";

export const kanjin3_2: Kanji[] = [
  { 
    char: '育', level: 'N3', onyomi: ['IKU'], kunyomi: ['soda(tsu)'], meaning: 'Tumbuh / Mendidik', strokes: 8,
    story: 'Anak (子) diberi daging/makanan (月) agar tumbuh besar.',
    examples: [
        { word: '育つ', reading: 'Sodatsu', meaning: 'Tumbuh' },
        { word: '育てる', reading: 'Sodateru', meaning: 'Membesarkan/Mendidik' },
        { word: '教育', reading: 'Kyouiku', meaning: 'Pendidikan' },
        { word: '体育', reading: 'Taiiku', meaning: 'Pendidikan Jasmani (Olahraga)' }
    ]
  },
  { 
    char: '種', level: 'N3', onyomi: ['SHU'], kunyomi: ['tane'], meaning: 'Biji / Jenis', strokes: 14,
    story: 'Padi (禾) yang berat (重) karena berisi biji.',
    examples: [
        { word: '種', reading: 'Tane', meaning: 'Biji/Benih' },
        { word: '種類', reading: 'Shurui', meaning: 'Jenis/Macam' },
        { word: '人種', reading: 'Jinshu', meaning: 'Ras' }
    ]
  },
  { 
    char: '類', level: 'N3', onyomi: ['RUI'], kunyomi: ['tagu(i)'], meaning: 'Jenis / Kategori', strokes: 18,
    story: 'Beras (米) dan anjing besar (大+犬). Mengelompokkan barang sejenis.',
    examples: [
        { word: '書類', reading: 'Shorui', meaning: 'Dokumen' },
        { word: '種類', reading: 'Shurui', meaning: 'Jenis' },
        { word: '人類', reading: 'Jinrui', meaning: 'Umat manusia' }
    ]
  },
  { 
    char: '師', level: 'N3', onyomi: ['SHI'], kunyomi: ['-'], meaning: 'Guru / Ahli', strokes: 10,
    story: 'Ahli yang memegang kain (巾) di kota (匝 tanpa garis atas).',
    examples: [
        { word: '教師', reading: 'Kyoushi', meaning: 'Guru/Pengajar' },
        { word: '医師', reading: 'Ishi', meaning: 'Dokter' },
        { word: '看護師', reading: 'Kangoshi', meaning: 'Perawat' }
    ]
  },
  { 
    char: '妻', level: 'N3', onyomi: ['SAI'], kunyomi: ['tsuma'], meaning: 'Istri', strokes: 8,
    story: 'Wanita (女) yang memegang sapu/peralatan rumah tangga.',
    examples: [
        { word: '妻', reading: 'Tsuma', meaning: 'Istri (saya)' },
        { word: '夫妻', reading: 'Fusai', meaning: 'Suami istri' }
    ]
  },
  { 
    char: '夫', level: 'N3', onyomi: ['FU', 'FUU'], kunyomi: ['otto'], meaning: 'Suami', strokes: 4,
    story: 'Orang besar (大) dengan satu garis lagi di atasnya (kepala keluarga).',
    examples: [
        { word: '夫', reading: 'Otto', meaning: 'Suami (saya)' },
        { word: '夫婦', reading: 'Fuufu', meaning: 'Suami istri' },
        { word: '丈夫', reading: 'Joubu', meaning: 'Kuat/Sehat' }
    ]
  }
];
