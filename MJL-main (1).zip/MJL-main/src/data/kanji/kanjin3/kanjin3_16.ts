
import { Kanji } from "../../../types";

export const kanjin3_16: Kanji[] = [
  // Akan diisi lebih lanjut
];
