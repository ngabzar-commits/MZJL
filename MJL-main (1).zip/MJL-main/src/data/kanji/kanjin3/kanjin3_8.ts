
import { Kanji } from "../../../types";

export const kanjin3_8: Kanji[] = [
  // Akan diisi lebih lanjut
];
