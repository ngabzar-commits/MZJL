
import { Kanji } from "../../../types";

export const kanjin3_15: Kanji[] = [
  // Akan diisi lebih lanjut
];
