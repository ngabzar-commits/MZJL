
import { Kanji } from "../../../types";

export const kanjin3_12: Kanji[] = [
  // Akan diisi lebih lanjut
];
