
import { Kanji } from "../../../types";

export const kanjin3_19: Kanji[] = [
  // Akan diisi lebih lanjut
];
