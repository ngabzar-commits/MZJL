
import { Kanji } from "../../../types";

export const kanjin3_7: Kanji[] = [
  // Akan diisi lebih lanjut
];
