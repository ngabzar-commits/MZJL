
import { Kanji } from "../../../types";

export const kanjin3_17: Kanji[] = [
  // Akan diisi lebih lanjut
];
