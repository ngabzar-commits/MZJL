
import { Kanji } from "../../../types";

export const kanjin1_14: Kanji[] = [
  // Akan diisi lebih lanjut
];
