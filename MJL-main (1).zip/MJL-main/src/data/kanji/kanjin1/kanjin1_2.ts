
import { Kanji } from "../../../types";

export const kanjin1_2: Kanji[] = [
  { 
    char: '託', level: 'N1', onyomi: ['TAKU'], kunyomi: ['kaこつ(ける)'], meaning: 'Menitipkan / Mempercayakan', strokes: 10,
    story: 'Berkata (言) kepada tunas muda (宅) untuk mempercayakan masa depan.',
    examples: [
      { word: '委託', reading: 'Itaku', meaning: 'Konsinyasi / Mempercayakan' },
      { word: '信託', reading: 'Shintaku', meaning: 'Amanat / Trust' },
      { word: '託児所', reading: 'Takujisho', meaning: 'Tempat penitipan anak' }
    ]
  },
  { 
    char: '諾', level: 'N1', onyomi: ['DAKU'], kunyomi: ['-'], meaning: 'Persetujuan / Izin', strokes: 15,
    story: 'Berkata (言) "muda" (若) artinya setuju untuk mencoba hal baru.',
    examples: [
      { word: '承諾', reading: 'Shoudaku', meaning: 'Persetujuan / Menerima' },
      { word: '許諾', reading: 'Kyodaku', meaning: 'Izin / Lisensi' }
    ]
  },
  { 
    char: '諭', level: 'N1', onyomi: ['YU'], kunyomi: ['sato(su)'], meaning: 'Menasihati / Menegur', strokes: 16,
    story: 'Berkata (言) dalam pertemuan (俞) untuk memberi nasihat bijak.',
    examples: [
      { word: '諭す', reading: 'Satosu', meaning: 'Menasihati / Menyadarkan' },
      { word: '教諭', reading: 'Kyouyu', meaning: 'Guru (istilah formal)' }
    ]
  },
  { 
    char: '諮', level: 'N1', onyomi: ['SHI'], kunyomi: ['haka(ru)'], meaning: 'Berkonsultasi', strokes: 16,
    story: 'Berkata (言) dan bertanya pada orang berikutnya (次) dan mulut (口) orang banyak.',
    examples: [
      { word: '諮問', reading: 'Shimon', meaning: 'Konsultasi / Pertanyaan (resmi)' },
      { word: '諮る', reading: 'Hakaru', meaning: 'Berkonsultasi / Meminta pendapat' }
    ]
  },
  { 
    char: '謀', level: 'N1', onyomi: ['BOU', 'MU'], kunyomi: ['haka(ru)'], meaning: 'Bersekongkol / Siasat', strokes: 16,
    story: 'Kata-kata (言) yang manis dari pohon tertentu (某) adalah sebuah siasat.',
    examples: [
      { word: '陰謀', reading: 'Inbou', meaning: 'Konspirasi / Persekongkolan' },
      { word: '無謀', reading: 'Mubou', meaning: 'Gabah / Tidak berpikir panjang' },
      { word: '謀る', reading: 'Hakaru', meaning: 'Merencanakan (jahat) / Menipu' }
    ]
  }
];
