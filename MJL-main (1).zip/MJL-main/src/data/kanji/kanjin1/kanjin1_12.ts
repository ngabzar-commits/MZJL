
import { Kanji } from "../../../types";

export const kanjin1_12: Kanji[] = [
  // Akan diisi lebih lanjut
];
