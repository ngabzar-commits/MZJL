
import { Kanji } from "../../../types";

export const kanjin1_17: Kanji[] = [
  // Akan diisi lebih lanjut
];
