
import { Kanji } from "../../../types";

export const kanjin1_20: Kanji[] = [
  // Akan diisi lebih lanjut
];
