
import { Kanji } from "../../../types";

export const kanjin1_13: Kanji[] = [
  // Akan diisi lebih lanjut
];
