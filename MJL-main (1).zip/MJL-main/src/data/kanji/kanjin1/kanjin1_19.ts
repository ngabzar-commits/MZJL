
import { Kanji } from "../../../types";

export const kanjin1_19: Kanji[] = [
  // Akan diisi lebih lanjut
];
