
import { Kanji } from "../../../types";

export const kanjin1_6: Kanji[] = [
  // Akan diisi lebih lanjut
];
