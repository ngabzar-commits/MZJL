
import { Kanji } from "../../../types";

export const kanjin1_16: Kanji[] = [
  // Akan diisi lebih lanjut
];
