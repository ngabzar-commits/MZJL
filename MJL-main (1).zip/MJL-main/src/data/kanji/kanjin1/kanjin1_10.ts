
import { Kanji } from "../../../types";

export const kanjin1_10: Kanji[] = [
  // Akan diisi lebih lanjut
];
