
import { Kanji } from "../../../types";

export const kanjin1_8: Kanji[] = [
  // Akan diisi lebih lanjut
];
