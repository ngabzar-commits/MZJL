import { Kana } from "../../../types";

export const hiragana_18: Kana[] = [];