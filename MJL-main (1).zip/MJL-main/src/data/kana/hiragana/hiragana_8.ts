import { Kana } from "../../../types";

export const hiragana_8: Kana[] = [];