import { Kana } from "../../../types";

export const hiragana_17: Kana[] = [];