import { Kana } from "../../../types";

export const hiragana_6: Kana[] = [];