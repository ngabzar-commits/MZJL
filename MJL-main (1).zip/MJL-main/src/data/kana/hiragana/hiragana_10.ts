import { Kana } from "../../../types";

export const hiragana_10: Kana[] = [];