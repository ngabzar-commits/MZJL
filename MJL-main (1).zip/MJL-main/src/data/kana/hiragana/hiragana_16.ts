import { Kana } from "../../../types";

export const hiragana_16: Kana[] = [];