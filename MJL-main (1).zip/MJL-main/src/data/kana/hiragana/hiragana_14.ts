import { Kana } from "../../../types";

export const hiragana_14: Kana[] = [];