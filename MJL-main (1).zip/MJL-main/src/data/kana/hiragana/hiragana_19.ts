import { Kana } from "../../../types";

export const hiragana_19: Kana[] = [];