import { Kana } from "../../../types";

export const hiragana_20: Kana[] = [];