import { Kana } from "../../../types";

export const hiragana_9: Kana[] = [];