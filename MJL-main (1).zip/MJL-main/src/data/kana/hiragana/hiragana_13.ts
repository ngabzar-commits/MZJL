import { Kana } from "../../../types";

export const hiragana_13: Kana[] = [];