import { Kana } from "../../../types";

export const katakana_8: Kana[] = [];