import { Kana } from "../../../types";

export const katakana_11: Kana[] = [];