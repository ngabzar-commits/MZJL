import { Kana } from "../../../types";

export const katakana_16: Kana[] = [];