import { Kana } from "../../../types";

export const katakana_12: Kana[] = [];