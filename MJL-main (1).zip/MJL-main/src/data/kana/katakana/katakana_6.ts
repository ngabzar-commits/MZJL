import { Kana } from "../../../types";

export const katakana_6: Kana[] = [];