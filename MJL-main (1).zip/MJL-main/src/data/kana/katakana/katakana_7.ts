import { Kana } from "../../../types";

export const katakana_7: Kana[] = [];