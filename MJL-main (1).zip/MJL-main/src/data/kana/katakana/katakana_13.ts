import { Kana } from "../../../types";

export const katakana_13: Kana[] = [];