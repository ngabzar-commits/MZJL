import { Kana } from "../../../types";

export const katakana_19: Kana[] = [];