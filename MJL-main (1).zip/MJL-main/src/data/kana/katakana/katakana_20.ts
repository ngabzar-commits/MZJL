import { Kana } from "../../../types";

export const katakana_20: Kana[] = [];