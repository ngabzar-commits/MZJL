import { Kana } from "../../../types";

export const katakana_14: Kana[] = [];