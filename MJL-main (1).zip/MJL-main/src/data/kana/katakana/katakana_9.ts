import { Kana } from "../../../types";

export const katakana_9: Kana[] = [];