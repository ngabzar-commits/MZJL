import { Kana } from "../../../types";

export const katakana_17: Kana[] = [];