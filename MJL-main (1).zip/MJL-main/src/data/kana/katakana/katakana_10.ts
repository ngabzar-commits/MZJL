import { Kana } from "../../../types";

export const katakana_10: Kana[] = [];