import { Kana } from "../../../types";

export const katakana_18: Kana[] = [];