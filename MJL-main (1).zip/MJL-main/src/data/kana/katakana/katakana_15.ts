import { Kana } from "../../../types";

export const katakana_15: Kana[] = [];