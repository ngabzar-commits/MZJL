// Database Writing Component Bagian 3
export const writing_component_3: Record<string, string> = {
  // Tambahkan data vector di sini
};
