import { Component, signal, computed, OnDestroy, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { JapaneseDataService } from '../services/data.service';
import { KanaToRomajiPipe } from '../pipes/kana-to-romaji.pipe';
import { Question } from '../types';
import { TranslationService } from '../services/translation.service';
import { TtsService } from '../services/tts.service';

// --- IMPORT DATABASE SOAL (N5) ---
import { jlptn5_1 } from '../data/soal/jlptn5_1'; import { jlptn5_2 } from '../data/soal/jlptn5_2';
import { jlptn5_3 } from '../data/soal/jlptn5_3'; import { jlptn5_4 } from '../data/soal/jlptn5_4';
import { jlptn5_5 } from '../data/soal/jlptn5_5'; import { jlptn5_6 } from '../data/soal/jlptn5_6';
import { jlptn5_7 } from '../data/soal/jlptn5_7'; import { jlptn5_8 } from '../data/soal/jlptn5_8';
import { jlptn5_9 } from '../data/soal/jlptn5_9'; import { jlptn5_10 } from '../data/soal/jlptn5_10';
import { jlptn5_11 } from '../data/soal/jlptn5_11'; import { jlptn5_12 } from '../data/soal/jlptn5_12';
import { jlptn5_13 } from '../data/soal/jlptn5_13'; import { jlptn5_14 } from '../data/soal/jlptn5_14';
import { jlptn5_15 } from '../data/soal/jlptn5_15'; import { jlptn5_16 } from '../data/soal/jlptn5_16';
import { jlptn5_17 } from '../data/soal/jlptn5_17'; import { jlptn5_18 } from '../data/soal/jlptn5_18';
import { jlptn5_19 } from '../data/soal/jlptn5_19'; import { jlptn5_20 } from '../data/soal/jlptn5_20';

// --- IMPORT DATABASE SOAL (N4) ---
import { jlptn4_1 } from '../data/soal/jlptn4_1'; import { jlptn4_2 } from '../data/soal/jlptn4_2';
import { jlptn4_3 } from '../data/soal/jlptn4_3'; import { jlptn4_4 } from '../data/soal/jlptn4_4';
import { jlptn4_5 } from '../data/soal/jlptn4_5'; import { jlptn4_6 } from '../data/soal/jlptn4_6';
import { jlptn4_7 } from '../data/soal/jlptn4_7'; import { jlptn4_8 } from '../data/soal/jlptn4_8';
import { jlptn4_9 } from '../data/soal/jlptn4_9'; import { jlptn4_10 } from '../data/soal/jlptn4_10';
import { jlptn4_11 } from '../data/soal/jlptn4_11'; import { jlptn4_12 } from '../data/soal/jlptn4_12';
import { jlptn4_13 } from '../data/soal/jlptn4_13'; import { jlptn4_14 } from '../data/soal/jlptn4_14';
import { jlptn4_15 } from '../data/soal/jlptn4_15'; import { jlptn4_16 } from '../data/soal/jlptn4_16';
import { jlptn4_17 } from '../data/soal/jlptn4_17'; import { jlptn4_18 } from '../data/soal/jlptn4_18';
import { jlptn4_19 } from '../data/soal/jlptn4_19'; import { jlptn4_20 } from '../data/soal/jlptn4_20';

// --- IMPORT DATABASE SOAL (JFT A2) ---
import { jftA2b_1 } from '../data/soal/jftA2b_1'; import { jftA2b_2 } from '../data/soal/jftA2b_2';
import { jftA2b_3 } from '../data/soal/jftA2b_3'; import { jftA2b_4 } from '../data/soal/jftA2b_4';
import { jftA2b_5 } from '../data/soal/jftA2b_5'; import { jftA2b_6 } from '../data/soal/jftA2b_6';
import { jftA2b_7 } from '../data/soal/jftA2b_7'; import { jftA2b_8 } from '../data/soal/jftA2b_8';
import { jftA2b_9 } from '../data/soal/jftA2b_9'; import { jftA2b_10 } from '../data/soal/jftA2b_10';
import { jftA2b_11 } from '../data/soal/jftA2b_11'; import { jftA2b_12 } from '../data/soal/jftA2b_12';
import { jftA2b_13 } from '../data/soal/jftA2b_13'; import { jftA2b_14 } from '../data/soal/jftA2b_14';
import { jftA2b_15 } from '../data/soal/jftA2b_15'; import { jftA2b_16 } from '../data/soal/jftA2b_16';
import { jftA2b_17 } from '../data/soal/jftA2b_17'; import { jftA2b_18 } from '../data/soal/jftA2b_18';
import { jftA2b_19 } from '../data/soal/jftA2b_19'; import { jftA2b_20 } from '../data/soal/jftA2b_20';

// --- IMPORT DATABASE SOAL (KALIMAT) ---
import { latihan_kalimat_1 } from '../data/soal/latihan.kalimat_1'; import { latihan_kalimat_2 } from '../data/soal/latihan.kalimat_2';
import { latihan_kalimat_3 } from '../data/soal/latihan.kalimat_3'; import { latihan_kalimat_4 } from '../data/soal/latihan.kalimat_4';
import { latihan_kalimat_5 } from '../data/soal/latihan.kalimat_5'; import { latihan_kalimat_6 } from '../data/soal/latihan.kalimat_6';
import { latihan_kalimat_7 } from '../data/soal/latihan.kalimat_7'; import { latihan_kalimat_8 } from '../data/soal/latihan.kalimat_8';
import { latihan_kalimat_9 } from '../data/soal/latihan.kalimat_9'; import { latihan_kalimat_10 } from '../data/soal/latihan.kalimat_10';
import { latihan_kalimat_11 } from '../data/soal/latihan.kalimat_11'; import { latihan_kalimat_12 } from '../data/soal/latihan.kalimat_12';
import { latihan_kalimat_13 } from '../data/soal/latihan.kalimat_13'; import { latihan_kalimat_14 } from '../data/soal/latihan.kalimat_14';
import { latihan_kalimat_15 } from '../data/soal/latihan.kalimat_15'; import { latihan_kalimat_16 } from '../data/soal/latihan.kalimat_16';
import { latihan_kalimat_17 } from '../data/soal/latihan.kalimat_17'; import { latihan_kalimat_18 } from '../data/soal/latihan.kalimat_18';
import { latihan_kalimat_19 } from '../data/soal/latihan.kalimat_19'; import { latihan_kalimat_20 } from '../data/soal/latihan.kalimat_20';

// --- IMPORT DATABASE SOAL (PARTIKEL) ---
import { latihan_partikel_1 } from '../data/soal/latihan.partikel_1'; import { latihan_partikel_2 } from '../data/soal/latihan.partikel_2';
import { latihan_partikel_3 } from '../data/soal/latihan.partikel_3'; import { latihan_partikel_4 } from '../data/soal/latihan.partikel_4';
import { latihan_partikel_5 } from '../data/soal/latihan.partikel_5'; import { latihan_partikel_6 } from '../data/soal/latihan.partikel_6';
import { latihan_partikel_7 } from '../data/soal/latihan.partikel_7'; import { latihan_partikel_8 } from '../data/soal/latihan.partikel_8';
import { latihan_partikel_9 } from '../data/soal/latihan.partikel_9'; import { latihan_partikel_10 } from '../data/soal/latihan.partikel_10';
import { latihan_partikel_11 } from '../data/soal/latihan.partikel_11'; import { latihan_partikel_12 } from '../data/soal/latihan.partikel_12';
import { latihan_partikel_13 } from '../data/soal/latihan.partikel_13'; import { latihan_partikel_14 } from '../data/soal/latihan.partikel_14';
import { latihan_partikel_15 } from '../data/soal/latihan.partikel_15'; import { latihan_partikel_16 } from '../data/soal/latihan.partikel_16';
import { latihan_partikel_17 } from '../data/soal/latihan.partikel_17'; import { latihan_partikel_18 } from '../data/soal/latihan.partikel_18';
import { latihan_partikel_19 } from '../data/soal/latihan.partikel_19'; import { latihan_partikel_20 } from '../data/soal/latihan.partikel_20';


@Component({
  selector: 'app-quiz',
  imports: [CommonModule, RouterLink, FormsModule, KanaToRomajiPipe],
  template: `
    <div class="min-h-screen bg-slate-950 pb-20 text-slate-200">
      <div class="sticky top-0 bg-slate-950 z-20 p-4 border-b border-slate-800 flex items-center justify-between gap-4">
        <div class="flex items-center gap-4">
          <a routerLink="/" class="text-slate-400 hover:text-white">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
              <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
            </svg>
          </a>
          <h1 class="text-xl font-bold text-slate-200">{{ ts.get('quiz.title') }}</h1>
        </div>
        
        <!-- Timer Display (Hanya muncul saat kuis jalan dan belum selesai) -->
        @if (isStarted() && !showResult()) {
          <div class="px-3 py-1 bg-slate-800 rounded-full border border-slate-700 font-mono text-lg font-bold" 
               [class.text-red-500]="remainingSeconds() < 60" 
               [class.text-blue-400]="remainingSeconds() >= 60">
            ⏱️ {{ formatTime(remainingSeconds()) }}
          </div>
        }
      </div>

      <div class="p-4">
        @if (!isStarted()) {
          <!-- MENU UTAMA KUIS -->
          <div class="space-y-8 mt-2 animate-in slide-in-from-bottom-4 duration-500">
            
            <!-- Section: Latihan Dasar -->
            <div>
              <h3 class="text-slate-400 text-sm font-bold uppercase tracking-wider mb-3 pl-1">Latihan Dasar</h3>
              <div class="grid grid-cols-1 gap-3">
                
                <!-- BUTTON KANA (Opens Selection Modal) -->
                <button (click)="openKanaSelection()" class="flex items-center p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-slate-700 transition group text-left">
                  <div class="w-12 h-12 rounded-lg bg-rose-900/30 flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform">あ</div>
                  <div>
                    <div class="font-bold text-rose-400">Latihan Kana</div>
                    <div class="text-xs text-slate-500">Hafalan Hiragana & Katakana</div>
                  </div>
                </button>

                <button (click)="openConfig('KANJI')" class="flex items-center p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-slate-700 transition group text-left">
                  <div class="w-12 h-12 rounded-lg bg-blue-900/30 flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform">字</div>
                  <div>
                    <div class="font-bold text-blue-400">Latihan Kanji N5/N4</div>
                    <div class="text-xs text-slate-500">Bacaan Onyomi & Kunyomi</div>
                  </div>
                </button>
                <button (click)="openConfig('VOCAB')" class="flex items-center p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-slate-700 transition group text-left">
                  <div class="w-12 h-12 rounded-lg bg-cyan-900/30 flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform">単</div>
                  <div>
                    <div class="font-bold text-cyan-400">Latihan Kosakata</div>
                    <div class="text-xs text-slate-500">Arti kata & penggunaan</div>
                  </div>
                </button>
                 <button (click)="openConfig('PARTICLE')" class="flex items-center p-4 bg-slate-900 border border-slate-800 rounded-xl hover:bg-slate-800 hover:border-slate-700 transition group text-left">
                  <div class="w-12 h-12 rounded-lg bg-amber-900/30 flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform">は</div>
                  <div>
                    <div class="font-bold text-amber-400">{{ ts.get('quiz.menu.particle') }}</div>
                    <div class="text-xs text-slate-500">{{ ts.get('quiz.menu.particle_desc') }}</div>
                  </div>
                </button>
              </div>
            </div>

            <!-- Section: Simulasi Ujian -->
            <div>
              <h3 class="text-slate-400 text-sm font-bold uppercase tracking-wider mb-3 pl-1">Simulasi Ujian & Kalimat</h3>
              <div class="grid grid-cols-1 gap-3">
                <!-- JLPT N5 -->
                <button (click)="openConfig('JLPT_N5')" class="relative overflow-hidden p-4 bg-slate-900 border border-amber-600/50 rounded-xl hover:bg-slate-800 transition group text-left">
                  <div class="absolute top-0 right-0 bg-amber-600 text-black text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">SIMULASI</div>
                  <div class="flex items-center">
                    <div class="w-12 h-12 rounded-lg bg-amber-900/20 border border-amber-600/30 flex items-center justify-center text-xl font-bold text-amber-500 mr-4 group-hover:scale-110 transition-transform">N5</div>
                    <div>
                      <div class="font-bold text-amber-400">JLPT N5 (Full Jepang)</div>
                      <div class="text-xs text-slate-500">Format soal asli 90% mirip</div>
                    </div>
                  </div>
                </button>

                <!-- JLPT N4 -->
                <button (click)="openConfig('JLPT_N4')" class="relative overflow-hidden p-4 bg-slate-900 border border-amber-600/50 rounded-xl hover:bg-slate-800 transition group text-left">
                  <div class="absolute top-0 right-0 bg-amber-600 text-black text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">SIMULASI</div>
                  <div class="flex items-center">
                    <div class="w-12 h-12 rounded-lg bg-amber-900/20 border border-amber-600/30 flex items-center justify-center text-xl font-bold text-amber-500 mr-4 group-hover:scale-110 transition-transform">N4</div>
                    <div>
                      <div class="font-bold text-amber-400">JLPT N4 (Full Jepang)</div>
                      <div class="text-xs text-slate-500">Tingkat lanjut, soal asli</div>
                    </div>
                  </div>
                </button>

                <!-- JFT A2 -->
                <button (click)="openConfig('JFT_A2')" class="relative overflow-hidden p-4 bg-slate-900 border border-emerald-600/50 rounded-xl hover:bg-slate-800 transition group text-left">
                  <div class="absolute top-0 right-0 bg-emerald-600 text-black text-[10px] font-bold px-2 py-0.5 rounded-bl-lg">JFT</div>
                  <div class="flex items-center">
                    <div class="w-12 h-12 rounded-lg bg-emerald-900/20 border border-emerald-600/30 flex items-center justify-center text-xl font-bold text-emerald-500 mr-4 group-hover:scale-110 transition-transform">A2</div>
                    <div>
                      <div class="font-bold text-emerald-400">JFT Basic A2</div>
                      <div class="text-xs text-slate-500">Ujian hidup & kerja (Tokutei)</div>
                    </div>
                  </div>
                </button>

                <!-- Soal Kalimat -->
                <button (click)="openConfig('SENTENCE')" class="flex items-center p-4 bg-slate-900 border border-purple-800 rounded-xl hover:bg-slate-800 hover:border-purple-600 transition group text-left">
                  <div class="w-12 h-12 rounded-lg bg-purple-900/30 flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform">✍️</div>
                  <div>
                    <div class="font-bold text-purple-400">Latihan Kalimat (Essay)</div>
                    <div class="text-xs text-slate-500">Terjemahan JP ↔ ID (Ketik)</div>
                  </div>
                </button>
              </div>
            </div>
          </div>

          <!-- MODAL PEMILIHAN KANA (New) -->
          @if (showKanaSelectionModal()) {
            <div class="fixed inset-0 z-50 flex items-center justify-center px-4">
              <div class="absolute inset-0 bg-black/80 backdrop-blur-sm" (click)="showKanaSelectionModal.set(false)"></div>
              <div class="relative bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-sm shadow-2xl animate-in zoom-in duration-200">
                <div class="text-center mb-6">
                  <h3 class="text-xl font-bold text-white mb-1">Pilih Jenis Soal Kana</h3>
                  <p class="text-slate-400 text-xs">Pilih huruf yang ingin dilatih</p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                  <button (click)="selectKanaQuiz('KANA_HIRAGANA')" class="p-6 bg-slate-800 border border-slate-600 rounded-xl hover:bg-slate-700 hover:border-rose-500 transition group">
                    <div class="text-4xl text-rose-400 font-bold mb-2 group-hover:scale-110 transition-transform">あ</div>
                    <div class="text-sm font-bold text-white">Hiragana</div>
                  </button>
                  <button (click)="selectKanaQuiz('KANA_KATAKANA')" class="p-6 bg-slate-800 border border-slate-600 rounded-xl hover:bg-slate-700 hover:border-blue-500 transition group">
                    <div class="text-4xl text-blue-400 font-bold mb-2 group-hover:scale-110 transition-transform">ア</div>
                    <div class="text-sm font-bold text-white">Katakana</div>
                  </button>
                </div>
                <button (click)="showKanaSelectionModal.set(false)" class="mt-6 w-full py-3 text-slate-500 font-bold hover:text-slate-300">Batal</button>
              </div>
            </div>
          }

          <!-- MODAL KONFIGURASI -->
          @if (showConfigModal()) {
            <div class="fixed inset-0 z-50 flex items-center justify-center px-4">
              <!-- Backdrop -->
              <div class="absolute inset-0 bg-black/80 backdrop-blur-sm" (click)="showConfigModal.set(false)"></div>
              
              <!-- Modal Content -->
              <div class="relative bg-slate-900 border border-slate-700 rounded-2xl p-6 w-full max-w-sm shadow-2xl animate-in zoom-in duration-200">
                <div class="text-center mb-6">
                  <h3 class="text-xl font-bold text-white mb-1">Pengaturan Kuis</h3>
                  <p class="text-slate-400 text-xs">Sesuaikan latihanmu</p>
                </div>

                <div class="space-y-4">
                  <!-- Input Waktu -->
                  <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1">Waktu (Menit)</label>
                    <div class="flex items-center">
                      <input type="number" min="1" max="500" [(ngModel)]="configDuration" 
                        class="block w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-center font-bold text-lg"
                        placeholder="1 - 500">
                    </div>
                    <div class="text-[10px] text-slate-500 mt-1 text-right">Maks: 500 menit</div>
                  </div>

                  <!-- Input Jumlah Soal -->
                  <div>
                    <label class="block text-sm font-medium text-slate-300 mb-1">Jumlah Soal</label>
                    <div class="flex items-center">
                      <input type="number" min="1" max="500" [(ngModel)]="configQuestionCount" 
                        class="block w-full px-4 py-3 bg-slate-800 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-center font-bold text-lg"
                        placeholder="1 - 500">
                    </div>
                    <!-- Tampilkan total ketersediaan soal -->
                    <div class="text-[10px] text-slate-500 mt-1 text-right">
                      Tersedia: <span class="text-blue-400 font-bold">{{ availableQuestionCount }}</span> soal
                    </div>
                  </div>
                </div>

                <div class="mt-8 flex gap-3">
                  <button (click)="showConfigModal.set(false)" class="flex-1 py-3 bg-slate-800 text-slate-300 font-bold rounded-xl hover:bg-slate-700 border border-slate-700 transition">
                    Batal
                  </button>
                  <button (click)="proceedToQuiz()" class="flex-1 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-500 shadow-lg shadow-blue-900/30 transition">
                    Mulai
                  </button>
                </div>
              </div>
            </div>
          }

        } @else if (currentQuestion()) {
          <!-- QUIZ INTERFACE -->
          <div class="mt-4 max-w-lg mx-auto animate-in fade-in duration-300">
             <!-- Progress Bar -->
             <div class="flex justify-between text-sm text-slate-500 mb-2">
               <span>Soal {{currentIndex() + 1}} / {{questions().length}}</span>
               <span>Skor: <span class="text-green-400 font-bold">{{score()}}</span></span>
             </div>
             <div class="h-1.5 bg-slate-800 rounded-full mb-8 overflow-hidden">
               <div class="h-full bg-blue-500 rounded-full transition-all duration-300 ease-out" [style.width.%]="((currentIndex() + 1) / questions().length) * 100"></div>
             </div>

             <!-- Question Card -->
             <div class="bg-slate-900 p-6 rounded-2xl border border-slate-800 min-h-[160px] flex flex-col items-center justify-center mb-6 text-center relative shadow-lg">
                <!-- Badge Tipe Soal -->
                <div class="absolute top-3 left-3 text-[10px] font-bold px-2 py-1 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {{ getQuizLabel(currentQuestion()!.type) }}
                </div>

                <!-- ROMAJI TOGGLE BUTTON -->
                <button (click)="toggleRomaji()" 
                  class="absolute top-3 right-3 px-3 py-1.5 rounded-lg border border-slate-700 font-bold text-xs transition-all z-10"
                  [class.bg-amber-900_20]="showRomaji()"
                  [class.text-amber-400]="showRomaji()"
                  [class.border-amber-500_50]="showRomaji()"
                  [class.bg-slate-800]="!showRomaji()"
                  [class.text-slate-400]="!showRomaji()">
                  あ/A
                </button>
                
                <div class="flex items-center gap-2 mb-2 w-full justify-center relative">
                  <h2 class="text-xl md:text-2xl font-bold text-white leading-relaxed whitespace-pre-line">{{ currentQuestion()?.q }}</h2>
                  <!-- Speaker Icon for Question -->
                  <button (click)="speakQuestion()" class="p-2 rounded-full bg-slate-800 text-blue-400 hover:bg-slate-700 transition absolute right-[-40px]">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-6 h-6">
                      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 2.485.519 4.952 1.848 6.595.342 1.241 1.519 1.905 2.66 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06ZM18.584 5.106a.75.75 0 0 1 1.06 0c3.808 3.807 3.808 9.98 0 13.788a.75.75 0 1 1-1.06-1.06 8.25 8.25 0 0 0 0-11.668.75.75 0 0 1 0-1.06Z" />
                    </svg>
                  </button>
                </div>

                <!-- ROMAJI DISPLAY (QUESTION) -->
                @if (showRomaji()) {
                  <div class="mt-4 text-amber-400/80 font-mono text-sm leading-relaxed border-t border-slate-800/50 pt-2 animate-in fade-in w-full">
                    {{ currentQuestion()?.q_romaji ? currentQuestion()!.q_romaji : (currentQuestion()?.q | kanaToRomaji) }}
                  </div>
                }
             </div>

             <!-- INPUT AREA: CHOICE vs ESSAY -->
             
             @if (currentQuestion()?.inputType === 'CHOICE') {
               <!-- PILIHAN GANDA -->
               <div class="grid grid-cols-1 gap-3">
                 @for (opt of currentQuestion()?.options; track opt; let i = $index) {
                   <button 
                    (click)="answerChoice(i)"
                    [disabled]="showResult()"
                    class="p-4 rounded-xl font-medium text-left transition-all border relative overflow-hidden group"
                    [class]="getOptionClass(i)"
                   >
                     <div class="flex items-start w-full">
                       <span class="inline-block w-6 h-6 rounded-full bg-slate-950/50 text-center leading-6 text-xs mr-3 border border-slate-700 text-slate-400 shrink-0 mt-0.5">{{ ['A','B','C','D'][i] }}</span>
                       <div class="flex-1 pr-6">
                         <div class="text-lg leading-relaxed">{{ opt }}</div>
                         <!-- ROMAJI DISPLAY (OPTION) -->
                         @if (showRomaji()) {
                           <div class="text-amber-400/80 font-mono text-xs mt-1 animate-in fade-in">
                             {{ opt | kanaToRomaji }}
                           </div>
                         }
                       </div>
                       <!-- Option Speaker Button -->
                       <div class="absolute right-3 top-3 z-10" *ngIf="!showResult()">
                          <button (click)="$event.stopPropagation(); tts.speak(opt, 'id-ID')" class="p-1.5 rounded-full text-slate-500 hover:text-blue-400 hover:bg-slate-800 transition">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-4 h-4">
                              <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 0 0 1.5 12c0 2.485.519 4.952 1.848 6.595.342 1.241 1.519 1.905 2.66 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06ZM18.584 5.106a.75.75 0 0 1 1.06 0c3.808 3.807 3.808 9.98 0 13.788a.75.75 0 1 1-1.06-1.06 8.25 8.25 0 0 0 0-11.668.75.75 0 0 1 0-1.06Z" />
                            </svg>
                          </button>
                       </div>
                     </div>
                     
                     <!-- Result Icons -->
                     @if (showResult()) {
                       @if (i === currentQuestion()!.correct) {
                         <span class="absolute right-4 top-1/2 -translate-y-1/2 text-green-400 font-bold text-xl">✓</span>
                       }
                       @if (i === selectedAnswer() && i !== currentQuestion()!.correct) {
                         <span class="absolute right-4 top-1/2 -translate-y-1/2 text-red-400 font-bold text-xl">✕</span>
                       }
                     }
                   </button>
                 }
               </div>
             } @else {
               <!-- ESSAY INPUT -->
               <div class="flex flex-col gap-4">
                 <input 
                   type="text" 
                   [(ngModel)]="essayAnswer" 
                   [disabled]="showResult()"
                   (keyup.enter)="!showResult() ? checkEssay() : null"
                   class="w-full p-4 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition text-center text-lg"
                   placeholder="Ketik jawaban di sini..."
                   autocomplete="off"
                 />
                 
                 @if (!showResult()) {
                   <button (click)="checkEssay()" 
                     [disabled]="!essayAnswer.trim()"
                     class="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-bold rounded-xl transition shadow-lg shadow-blue-900/20">
                     Jawab
                   </button>
                 } @else {
                   <!-- Essay Feedback -->
                   <div class="p-4 rounded-xl border text-center" 
                     [class]="isEssayCorrect ? 'bg-green-900/20 border-green-900 text-green-400' : 'bg-red-900/20 border-red-900 text-red-400'">
                     <div class="font-bold text-lg mb-1">{{ isEssayCorrect ? 'Benar!' : 'Kurang Tepat' }}</div>
                     @if (!isEssayCorrect) {
                        <div class="text-sm text-slate-400">Jawaban yang benar:</div>
                        <div class="text-white font-bold">{{ currentQuestion()?.correctAnswers?.[0] }}</div>
                     }
                   </div>
                 }
               </div>
             }

             <!-- Explanation & Next Button -->
             @if (showResult()) {
               <div class="mt-6 animate-in fade-in slide-in-from-bottom-2">
                 @if (currentQuestion()?.explanation) {
                   <div class="mb-4 p-4 bg-slate-800/80 rounded-xl text-sm text-slate-300 border border-slate-700/50 shadow-sm">
                     <div class="flex items-center gap-2 mb-2 border-b border-slate-700 pb-2">
                        <span class="text-lg">💡</span>
                        <span class="font-bold text-blue-400 uppercase tracking-wider text-xs">Pembahasan Detail</span>
                     </div>
                     <div class="whitespace-pre-wrap leading-relaxed opacity-90 text-left">
                       {{ currentQuestion()?.explanation }}
                     </div>
                   </div>
                 }
                 
                 <div class="flex justify-center">
                   <button (click)="next()" class="px-8 py-3 bg-white text-slate-950 font-bold rounded-full hover:bg-slate-200 transition shadow-lg hover:scale-105 active:scale-95">
                     {{ currentIndex() < questions().length - 1 ? 'Soal Berikutnya →' : 'Lihat Hasil 🏆' }}
                   </button>
                 </div>
               </div>
             }
          </div>
        } @else {
          <!-- Result Screen -->
           <div class="text-center mt-12 space-y-6 px-4 animate-in zoom-in duration-300">
             <div class="text-7xl mb-4 filter drop-shadow-[0_0_15px_rgba(250,204,21,0.3)]">
               {{ score() > questions().length / 2 ? '🏆' : '💪' }}
             </div>
             <div>
               <h2 class="text-3xl font-bold text-white mb-2">Selesai!</h2>
               <p class="text-slate-400">{{ timeIsUp ? 'Waktu habis.' : 'Kamu telah menyelesaikan sesi ini.' }}</p>
             </div>
             
             <div class="py-6 bg-slate-900 rounded-2xl border border-slate-800 max-w-xs mx-auto">
                <div class="text-sm text-slate-500 uppercase tracking-widest font-bold mb-1">Skor Akhir</div>
                <div class="text-5xl font-black" [class]="getScoreColor()">
                  {{score()}} <span class="text-2xl text-slate-600 font-medium">/ {{questions().length}}</span>
                </div>
             </div>
             
             <button (click)="isStarted.set(false)" class="w-full max-w-xs py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-500 transition shadow-lg shadow-blue-900/20">
               Kembali ke Menu
             </button>
           </div>
        }
      </div>
    </div>
  `
})
export class QuizComponent implements OnDestroy {
  dataService = inject(JapaneseDataService);
  ts = inject(TranslationService);
  tts = inject(TtsService); // Inject TTS

  // Config States
  showConfigModal = signal(false);
  showKanaSelectionModal = signal(false); // New State for Kana Selection
  configDuration = 10;
  configQuestionCount = 10;
  selectedQuizType: 'KANA_HIRAGANA' | 'KANA_KATAKANA' | 'KANJI' | 'VOCAB' | 'PARTICLE' | 'JLPT_N5' | 'JLPT_N4' | 'JFT_A2' | 'SENTENCE' | '' = '';
  availableQuestionCount = 0; // Info jumlah soal tersedia

  // Quiz States
  isStarted = signal(false);
  questions = signal<Question[]>([]);
  currentIndex = signal(0);
  score = signal(0);
  showResult = signal(false);
  showRomaji = signal(false); // Toggle Romaji State
  
  // Timer States
  remainingSeconds = signal(0);
  timerInterval: any = null;
  timeIsUp = false;

  // Answer States
  selectedAnswer = signal<number | null>(null);
  essayAnswer = '';
  isEssayCorrect = false;

  ngOnDestroy() {
    this.stopTimer();
  }

  // --- KANA SELECTION LOGIC ---
  openKanaSelection() {
    this.showKanaSelectionModal.set(true);
  }

  selectKanaQuiz(type: 'KANA_HIRAGANA' | 'KANA_KATAKANA') {
    this.showKanaSelectionModal.set(false);
    this.openConfig(type);
  }

  // --- CONFIG & START LOGIC ---

  openConfig(type: any) {
    this.selectedQuizType = type;
    this.configDuration = 10;
    this.configQuestionCount = 10;
    
    // Hitung jumlah soal tersedia saat membuka config
    const fullData = this.getQuestionsByType(type);
    this.availableQuestionCount = fullData.length;

    this.showConfigModal.set(true);
  }

  proceedToQuiz() {
    // Validasi Input
    if (this.configDuration < 1) this.configDuration = 1;
    if (this.configDuration > 500) this.configDuration = 500;
    if (this.configQuestionCount < 1) this.configQuestionCount = 1;
    if (this.configQuestionCount > 500) this.configQuestionCount = 500;

    // Load Data
    const fullQuestions = this.getQuestionsByType(this.selectedQuizType);
    
    // Shuffle & Slice
    // Mengambil sejumlah yang diminta, tapi tidak lebih dari yang tersedia
    const shuffled = this.shuffleArray(fullQuestions);
    const sliceCount = Math.min(this.configQuestionCount, fullQuestions.length);
    const sliced = shuffled.slice(0, sliceCount);
    
    // Setup Quiz
    this.questions.set(sliced);
    this.currentIndex.set(0);
    this.score.set(0);
    this.showResult.set(false);
    this.showRomaji.set(false); // Reset romaji state at start
    this.selectedAnswer.set(null);
    this.essayAnswer = '';
    this.isEssayCorrect = false;
    this.timeIsUp = false;

    // Setup Timer
    this.remainingSeconds.set(this.configDuration * 60);
    this.startTimer();

    this.showConfigModal.set(false);
    this.isStarted.set(true);
  }

  // --- TIMER LOGIC ---

  startTimer() {
    this.stopTimer(); // Clear existing if any
    this.timerInterval = setInterval(() => {
      const current = this.remainingSeconds();
      if (current > 0) {
        this.remainingSeconds.set(current - 1);
      } else {
        this.finishQuizByTimeout();
      }
    }, 1000);
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  finishQuizByTimeout() {
    this.stopTimer();
    this.timeIsUp = true;
    this.isStarted.set(false); // Langsung ke result screen
  }

  formatTime(seconds: number): string {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  // --- HELPER LOGIC ---

  toggleRomaji() {
    this.showRomaji.update(v => !v);
  }

  shuffleArray(array: any[]) {
    // Fisher-Yates shuffle
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  currentQuestion() {
    if (this.currentIndex() >= this.questions().length) return null;
    return this.questions()[this.currentIndex()];
  }

  speakQuestion() {
    const q = this.currentQuestion();
    if (!q) return;
    
    // Default to 'id-ID' as base because it's an app for Indonesian learners.
    // The TTS Service will smart-detect Japanese segments and switch voice automatically.
    this.tts.speak(q.q, 'id-ID');
  }

  getQuizLabel(type: string) {
    switch(type) {
      case 'JLPT_N5': return 'JLPT N5';
      case 'JLPT_N4': return 'JLPT N4';
      case 'JFT_A2': return 'JFT Basic A2';
      case 'SENTENCE': return 'Latihan Kalimat';
      case 'PARTICLE': return 'Latihan Partikel';
      case 'KANA_HIRAGANA': return 'Hiragana Quiz';
      case 'KANA_KATAKANA': return 'Katakana Quiz';
      default: return 'Quiz';
    }
  }

  getScoreColor() {
    const s = this.score();
    const total = this.questions().length;
    if (total === 0) return 'text-slate-200';
    const percentage = s / total;
    if (percentage >= 0.8) return 'text-green-400';
    if (percentage >= 0.5) return 'text-yellow-400';
    return 'text-red-400';
  }

  // --- DATA LOADING & AGGREGATION ---

  getQuestionsByType(type: string): Question[] {
    let qData: Question[] = [];

    switch (type) {
      case 'KANA_HIRAGANA':
        {
          const hiragana = this.dataService.getKana('HIRAGANA', 'GOJUUON');
          // Include dakuon/yoon for complexity? Let's stick to Gojuuon for consistency with simple drill
          // Or fetch all available
          const dakuon = this.dataService.getKana('HIRAGANA', 'DAKUON');
          const handakuon = this.dataService.getKana('HIRAGANA', 'HANDAKUON');
          const allHiragana = [...hiragana, ...dakuon, ...handakuon];

          qData = allHiragana.map(k => {
            const wrongs = [];
            while(wrongs.length < 3) {
               const r = allHiragana[Math.floor(Math.random() * allHiragana.length)];
               if (r.romaji !== k.romaji && !wrongs.includes(r.romaji)) {
                 wrongs.push(r.romaji);
               }
            }
            const opts = this.shuffleArray([k.romaji, ...wrongs]);
            
            return {
              q: `Apa bacaan dari karakter ini?\n\n${k.char}`,
              options: opts,
              correct: opts.indexOf(k.romaji),
              type: 'KANA',
              inputType: 'CHOICE'
            } as Question;
          });
        }
        break;

      case 'KANA_KATAKANA':
        {
          const katakana = this.dataService.getKana('KATAKANA', 'GOJUUON');
          const dakuon = this.dataService.getKana('KATAKANA', 'DAKUON');
          const handakuon = this.dataService.getKana('KATAKANA', 'HANDAKUON');
          const allKatakana = [...katakana, ...dakuon, ...handakuon];

          qData = allKatakana.map(k => {
            const wrongs = [];
            while(wrongs.length < 3) {
               const r = allKatakana[Math.floor(Math.random() * allKatakana.length)];
               if (r.romaji !== k.romaji && !wrongs.includes(r.romaji)) {
                 wrongs.push(r.romaji);
               }
            }
            const opts = this.shuffleArray([k.romaji, ...wrongs]);
            
            return {
              q: `Apa bacaan dari karakter ini?\n\n${k.char}`,
              options: opts,
              correct: opts.indexOf(k.romaji),
              type: 'KANA',
              inputType: 'CHOICE'
            } as Question;
          });
        }
        break;

      case 'KANJI':
        // Generate Kanji Questions Dynamically
        const allKanji = this.dataService.getKanji('ALL');
        qData = allKanji.map(k => {
           const wrongs = [];
           while(wrongs.length < 3) {
             const r = allKanji[Math.floor(Math.random() * allKanji.length)];
             if (r.meaning !== k.meaning && !wrongs.includes(r.meaning)) {
               wrongs.push(r.meaning);
             }
           }
           const opts = this.shuffleArray([k.meaning, ...wrongs]);
           
           return {
             q: `Apa arti dari Kanji ini?\n\n${k.char}\n(On: ${k.onyomi.join(', ')} | Kun: ${k.kunyomi.join(', ')})`,
             options: opts,
             correct: opts.indexOf(k.meaning),
             type: 'KANJI',
             inputType: 'CHOICE',
             explanation: k.story || `Kanji ${k.char} berarti ${k.meaning}.`
           } as Question;
        });
        break;

      case 'VOCAB':
        // Generate Vocab Questions Dynamically
        const allVocab = this.dataService.getVocab('ALL');
        qData = allVocab.map(v => {
           const wrongs = [];
           while(wrongs.length < 3) {
             const r = allVocab[Math.floor(Math.random() * allVocab.length)];
             if (r.meaning !== v.meaning && !wrongs.includes(r.meaning)) {
               wrongs.push(r.meaning);
             }
           }
           const opts = this.shuffleArray([v.meaning, ...wrongs]);

           return {
             q: `Apa arti kosakata ini?\n\n${v.word} (${v.kana})`,
             options: opts,
             correct: opts.indexOf(v.meaning),
             type: 'VOCAB',
             inputType: 'CHOICE'
           } as Question;
        });
        break;
        
      case 'JLPT_N5':
        qData = [
          ...jlptn5_1, ...jlptn5_2, ...jlptn5_3, ...jlptn5_4, ...jlptn5_5,
          ...jlptn5_6, ...jlptn5_7, ...jlptn5_8, ...jlptn5_9, ...jlptn5_10,
          ...jlptn5_11, ...jlptn5_12, ...jlptn5_13, ...jlptn5_14, ...jlptn5_15,
          ...jlptn5_16, ...jlptn5_17, ...jlptn5_18, ...jlptn5_19, ...jlptn5_20
        ];
        break;

      case 'JLPT_N4':
        qData = [
          ...jlptn4_1, ...jlptn4_2, ...jlptn4_3, ...jlptn4_4, ...jlptn4_5,
          ...jlptn4_6, ...jlptn4_7, ...jlptn4_8, ...jlptn4_9, ...jlptn4_10,
          ...jlptn4_11, ...jlptn4_12, ...jlptn4_13, ...jlptn4_14, ...jlptn4_15,
          ...jlptn4_16, ...jlptn4_17, ...jlptn4_18, ...jlptn4_19, ...jlptn4_20
        ];
        break;

      case 'JFT_A2':
        qData = [
          ...jftA2b_1, ...jftA2b_2, ...jftA2b_3, ...jftA2b_4, ...jftA2b_5,
          ...jftA2b_6, ...jftA2b_7, ...jftA2b_8, ...jftA2b_9, ...jftA2b_10,
          ...jftA2b_11, ...jftA2b_12, ...jftA2b_13, ...jftA2b_14, ...jftA2b_15,
          ...jftA2b_16, ...jftA2b_17, ...jftA2b_18, ...jftA2b_19, ...jftA2b_20
        ];
        break;

      case 'SENTENCE':
        qData = [
          ...latihan_kalimat_1, ...latihan_kalimat_2, ...latihan_kalimat_3, ...latihan_kalimat_4,
          ...latihan_kalimat_5, ...latihan_kalimat_6, ...latihan_kalimat_7, ...latihan_kalimat_8,
          ...latihan_kalimat_9, ...latihan_kalimat_10, ...latihan_kalimat_11, ...latihan_kalimat_12,
          ...latihan_kalimat_13, ...latihan_kalimat_14, ...latihan_kalimat_15, ...latihan_kalimat_16,
          ...latihan_kalimat_17, ...latihan_kalimat_18, ...latihan_kalimat_19, ...latihan_kalimat_20
        ];
        break;

      case 'PARTICLE':
        qData = [
          ...latihan_partikel_1, ...latihan_partikel_2, ...latihan_partikel_3, ...latihan_partikel_4,
          ...latihan_partikel_5, ...latihan_partikel_6, ...latihan_partikel_7, ...latihan_partikel_8,
          ...latihan_partikel_9, ...latihan_partikel_10, ...latihan_partikel_11, ...latihan_partikel_12,
          ...latihan_partikel_13, ...latihan_partikel_14, ...latihan_partikel_15, ...latihan_partikel_16,
          ...latihan_partikel_17, ...latihan_partikel_18, ...latihan_partikel_19, ...latihan_partikel_20
        ];
        break;
    }

    return qData;
  }

  // --- GAMEPLAY LOGIC ---

  answerChoice(index: number) {
    if (this.showResult()) return;
    
    this.selectedAnswer.set(index);
    this.showResult.set(true);
    
    if (index === this.currentQuestion()!.correct) {
      this.score.update(s => s + 1);
    }
  }

  checkEssay() {
    if (this.showResult() || !this.essayAnswer.trim()) return;

    const correctAnswers = this.currentQuestion()?.correctAnswers || [];
    const userAnswer = this.essayAnswer.toLowerCase().trim().replace(/[.,?!]/g, '');

    this.isEssayCorrect = correctAnswers.some(ans => 
      ans.toLowerCase().replace(/[.,?!]/g, '') === userAnswer
    );

    if (this.isEssayCorrect) {
      this.score.update(s => s + 1);
    }

    this.showResult.set(true);
  }

  next() {
    if (this.currentIndex() < this.questions().length - 1) {
      this.currentIndex.update(i => i + 1);
      this.showResult.set(false);
      this.showRomaji.set(false); // Reset romaji state
      this.selectedAnswer.set(null);
      this.essayAnswer = '';
      this.isEssayCorrect = false;
    } else {
      // Selesai (Manual Finish)
      this.stopTimer();
      this.isStarted.set(false);
    }
  }

  getOptionClass(index: number): string {
    if (!this.showResult()) {
      return 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800 hover:border-slate-500';
    }
    const q = this.currentQuestion()!;
    if (index === q.correct) {
      return 'bg-green-900/40 border-green-500 text-green-300 shadow-[0_0_10px_rgba(34,197,94,0.2)]';
    }
    if (index === this.selectedAnswer() && index !== q.correct) {
      return 'bg-red-900/40 border-red-500 text-red-300';
    }
    return 'bg-slate-900 border-slate-800 text-slate-500 opacity-50';
  }
}