// Database Writing Component Bagian 2
export const writing_component_2: Record<string, string> = {
  // Tambahkan data vector di sini
};
